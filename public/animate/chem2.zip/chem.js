(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"chem_atlas_1", frames: [[0,0,1914,1187]]},
		{name:"chem_atlas_2", frames: [[1233,702,206,80],[1751,804,264,85],[563,1042,264,47],[1449,312,87,47],[829,1042,212,47],[0,0,998,190],[815,263,409,261],[0,413,409,219],[0,634,409,133],[1449,435,409,176],[411,704,409,133],[822,839,409,90],[0,904,409,90],[822,704,409,133],[815,526,409,176],[1799,945,245,47],[1845,380,120,47],[1845,184,174,47],[1799,994,227,47],[1845,282,128,47],[815,192,160,47],[1845,233,160,47],[1845,0,173,90],[1845,92,173,90],[1043,1042,210,47],[1255,1042,210,47],[1000,0,564,261],[1644,891,346,52],[1449,263,104,47],[822,950,564,90],[411,974,346,52],[1845,331,126,47],[1751,715,282,87],[411,413,120,47],[1388,950,409,90],[0,769,409,133],[1233,815,409,133],[411,839,409,133],[304,1028,257,52],[0,996,302,52],[0,192,564,219],[1566,0,277,433],[566,192,247,485],[1449,613,300,200],[1751,613,280,100],[1226,263,221,437]]},
		{name:"chem_atlas_3", frames: [[0,0,638,1120],[1272,517,248,987],[1522,993,345,606],[1272,0,640,515],[0,1122,788,693],[790,1025,480,949],[640,0,518,1023],[1522,517,474,474]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_45 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_44 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_42 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_39 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["chem_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["chem_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["chem_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.beaker_2 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.conicalflask2 = function() {
	this.initialize(ss["chem_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Handlens = function() {
	this.initialize(ss["chem_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.mc = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.mortar = function() {
	this.initialize(ss["chem_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.new_therm = function() {
	this.initialize(ss["chem_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.pipette = function() {
	this.initialize(ss["chem_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.R1 = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.table_texture = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.thremovebgpreview1 = function() {
	this.initialize(ss["chem_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.tube = function() {
	this.initialize(ss["chem_atlas_2"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.an_TextInput = function(options) {
	this.initialize();
	this._element = new $.an.TextInput(options);
	this._el = this._element.create();
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,22);

p._tick = _tick;
p._handleDrawEnd = _handleDrawEnd;
p._updateVisibility = _updateVisibility;
p.draw = _componentDraw;



(lib.Symbol74 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_45();
	this.instance.setTransform(-52.3,-21.45,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_44();
	this.instance_1.setTransform(-66,-21.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol74, new cjs.Rectangle(-66,-21.4,132,42.7), null);


(lib.Symbol73 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#252525").s().p("AgNAOQgFgGAAgIQAAgHAFgGQAGgFAHAAQAIAAAGAFQAFAGAAAHQAAAIgFAGQgGAFgIAAQgHAAgGgFg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol73, new cjs.Rectangle(-1.9,-1.9,3.8,3.8), null);


(lib.Symbol72 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_43();
	this.instance.setTransform(-243.95,15.85,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_42();
	this.instance_1.setTransform(-243.95,-11.35,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_41();
	this.instance_2.setTransform(-243.95,-38.55,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_40();
	this.instance_3.setTransform(-249.45,-47.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-249.4,-47.5,499,95);


(lib.Symbol70 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.conicalflask2();
	this.instance.setTransform(-31.45,-55.25,0.1824,0.1824);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(204,204,204,0.557)").s().p("Ai2DbQhMgaAAgmIAAgFIB8l0IACAAQAIgIAagHQAlgIA0gBQA0ABAlAIQAaAHAIAIIABAAICQF0IAAADIAAACQAAAmhMAaQhMAbhrAAQhrAAhLgbg");
	this.shape.setTransform(1.275,24.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol70, new cjs.Rectangle(-31.4,-55.2,62.9,110.5), null);


(lib.Symbol69 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.thremovebgpreview1();
	this.instance.setTransform(-237,-237);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol69, new cjs.Rectangle(-237,-237,474,474), null);


(lib.Symbol68 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.mc();
	this.instance.setTransform(-123.5,-242.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol68, new cjs.Rectangle(-123.5,-242.5,247,485), null);


(lib.Symbol67 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.conicalflask2();
	this.instance.setTransform(-172.5,-303);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol67, new cjs.Rectangle(-172.5,-303,345,606), null);


(lib.Symbol65 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.beaker_2();
	this.instance.setTransform(-138.5,-216.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol65, new cjs.Rectangle(-138.5,-216.5,277,433), null);


(lib.Symbol63 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.counter = new cjs.Text("00:00", "8px 'Stencil'");
	this.counter.name = "counter";
	this.counter.textAlign = "center";
	this.counter.lineHeight = 11;
	this.counter.lineWidth = 25;
	this.counter.parent = this;
	this.counter.setTransform(1.65,-9.3);

	this.timeline.addTween(cjs.Tween.get(this.counter).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6A7D6A").s().p("AhiBjQgpgpAAg6QAAg6ApgpQApgoA5AAQA6AAApAoQApApAAA6QAAA6gpApQgpApg6AAQg5AAgpgpg");
	this.shape.setTransform(1.25,-4.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.thremovebgpreview1();
	this.instance.setTransform(-42.65,-42.65,0.18,0.18);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol63, new cjs.Rectangle(-42.6,-42.6,85.30000000000001,85.30000000000001), null);


(lib.Symbol61 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.thermReading = new cjs.Text("", "bold 4px 'Verdana'");
	this.thermReading.name = "thermReading";
	this.thermReading.textAlign = "center";
	this.thermReading.lineHeight = 7;
	this.thermReading.lineWidth = 18;
	this.thermReading.parent = this;
	this.thermReading.setTransform(5.4609,-14.0418,1,1,-91.0002);

	this.timeline.addTween(cjs.Tween.get(this.thermReading).wait(1));

	// Layer_1
	this.instance = new lib.new_therm();
	this.instance.setTransform(-26.4,-52.15,0.11,0.11);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol61, new cjs.Rectangle(-26.4,-52.1,52.8,104.30000000000001), null);


(lib.Symbol58 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFE0").s().p("Ao8KuQjthUAAh3IABgOIGCyPIAJAAQAZgZBRgTQBzgbCkAAQCjAABzAbQBRATAZAZIAEAAIHCSQIAAAGIAAAHQAAB3jtBUQjtBUlQAAQlPAAjthUg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol58, new cjs.Rectangle(-81,-77,162.1,154.1), null);


(lib.Symbol56 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.mc();
	this.instance.setTransform(-27.4,-53.8,0.222,0.222);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol56, new cjs.Rectangle(-27.4,-53.8,54.9,107.69999999999999), null);


(lib.Symbol53 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.mc();
	this.instance.setTransform(-74.1,-145.5,0.6,0.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.039)").s().p("AubW6MAAAgtzIc3AAMAAAAtzg");
	this.shape.setTransform(18.325,1.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol53, new cjs.Rectangle(-74.1,-145.5,184.8,293.1), null);


(lib.Symbol48 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.instance = new lib.CachedBmp_34();
	this.instance.setTransform(-102.3,95.4,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_33();
	this.instance_1.setTransform(-102.3,38.7,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_32();
	this.instance_2.setTransform(-102.3,-42.5,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_31();
	this.instance_3.setTransform(-102.3,-140.25,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_39();
	this.instance_4.setTransform(-106.5,207.2,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_38();
	this.instance_5.setTransform(-106.5,89.1,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_37();
	this.instance_6.setTransform(-106.5,17.25,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_36();
	this.instance_7.setTransform(-106.5,-73.7,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_35();
	this.instance_8.setTransform(-106.5,-142.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106.5,-142.7,208.7,480.4);


(lib.Symbol46 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.beaker_2();
	this.instance.setTransform(-91.4,-142.85,0.66,0.66);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol46, new cjs.Rectangle(-91.4,-142.8,182.8,285.70000000000005), null);


(lib.Symbol44 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0000FF").ss(9,1,1).p("AAAAAIG9FWAG8lVIm8FVIm8FWAm7lVIG7FV");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol44, new cjs.Rectangle(-48.9,-38.6,97.9,77.30000000000001), null);


(lib.Symbol42 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().bs(cjs.SpriteSheetUtils.extractFrame(ss["chem_atlas_2"],44)).ss(1,1,1).p("EgmVgVPMBMrAAAMAAAAqfMhMrAAAg");
	this.shape.setTransform(0.025,0);

	this.shape_1 = new cjs.Shape();
	var sprImg_shape_1 = cjs.SpriteSheetUtils.extractFrame(ss["chem_atlas_2"],44);
	sprImg_shape_1.onload = function(){
		this.shape_1.graphics.bf(sprImg_shape_1, null, new cjs.Matrix2D(1,0,0,1,-140,-50)).s().p("EgmVAVQMAAAgqfMBMrAAAMAAAAqfg")
	}.bind(this);
	this.shape_1.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol42, new cjs.Rectangle(-246.3,-137,492.70000000000005,274), null);


(lib.Symbol34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol34, new cjs.Rectangle(-97.9,-84.8,195.9,169.7), null);


(lib.Symbol33 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol33, new cjs.Rectangle(-97.9,-84.8,195.9,169.7), null);


(lib.Symbol32 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol32, new cjs.Rectangle(-97.9,-84.8,195.9,169.7), null);


(lib.Symbol31 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AtaNFQhugOAAh8IAA11QAAiICGgDIaFAAQCGADAACIIAAV1QAAABAAABQAAAFAAAFQAAAGgBAFQAAACAAABQAAABAAABQgEAggNAXQgBABAAABQgBABAAABQgBAAAAABQgBAAAAABQAAAAAAABIgBAAQgfAthIAEQgCAAgDAAI6PAAQgGAAgFgB");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol31, new cjs.Rectangle(-97.9,-84.8,195.9,169.7), null);


(lib.Symbol30 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol30, new cjs.Rectangle(-97.9,-84.8,195.9,169.7), null);


(lib.Symbol29 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol29, new cjs.Rectangle(-97.9,-84.8,195.9,169.7), null);


(lib.Symbol28 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol28, new cjs.Rectangle(-97.9,-84.8,195.9,169.7), null);


(lib.Symbol27 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol27, new cjs.Rectangle(-97.9,-84.8,195.9,169.7), null);


(lib.Symbol26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol26, new cjs.Rectangle(-97.9,-84.8,195.9,169.7), null);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_16();
	this.instance.setTransform(-26.75,-12.7,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_15();
	this.instance_1.setTransform(-70.5,-21.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.5,-21.8,141,43.5);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_12();
	this.instance.setTransform(-26.75,-12.7,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_15();
	this.instance_1.setTransform(-70.5,-21.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.5,-21.8,141,43.5);


(lib.Symbol30copy2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(0.1,1,1).p("AAaggICEimAidDHICkjP");
	this.shape.setTransform(-0.025,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C2C2C2").s().p("AidgoQAAieCdAAICeAAIiECnIhIhAIAtAAQAHgHgUgFIg/AAIAABEQAFANAGgEIAAgqIBJBBIikDOg");
	this.shape_1.setTransform(-0.025,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgogNIAAApQgGAEgFgOIAAhDIA+AAQAUAFgHAHIgsAAIBIA/IgUAYg");
	this.shape_2.setTransform(-2.6,-5.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FE8A1D").s().p("AidgoQAAieCdAAICeAAIiECnIhIhAIAtAAQAHgHgUgFIg/AAIAABEQAFANAGgEIAAgqIBJBBIikDOg");
	this.shape_3.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_3},{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.8,-20.8,33.6,41.7);


(lib.an_CSS = function(options) {
	this.initialize();
	this._element = new $.an.CSS(options);
	this._el = this._element.create();
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,22);

p._tick = _tick;
p._handleDrawEnd = _handleDrawEnd;
p._updateVisibility = _updateVisibility;
p.draw = _componentDraw;



(lib.Symbol60 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Symbol56();
	this.instance.setTransform(-0.05,-0.05,2.35,2.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFE0").s().p("AiIFQIAAqzQABAPBWgQIAYAAQBSAdAFgdIAdAAQApAXAFgXIAAK0QhUAVhDAAQhFAAg1gVg");
	this.shape.setTransform(16.95,63.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol60, new cjs.Rectangle(-64.4,-126.5,128.9,253), null);


(lib.Symbol57 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.conicalflask2();
	this.instance.setTransform(-98.35,-172.7,0.57,0.57);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.Symbol58();
	this.instance_1.setTransform(3.8,76.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol57, new cjs.Rectangle(-98.3,-172.7,196.6,345.4), null);


(lib.Symbol54 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_254 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(254).call(this.frame_254).wait(1));

	// Layer_10
	this.instance = new lib.Symbol56();
	this.instance.setTransform(-510.85,-171.1,2.58,2.58,96.7401);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(204).to({_off:false},0).to({scaleX:1,scaleY:1,rotation:0,guide:{path:[-510.6,-171.1,-277.2,-314.4,-5.5,-255]},visible:false},50).wait(1));

	// Layer_8
	this.instance_1 = new lib.Symbol56();
	this.instance_1.setTransform(-533.6,-56.45,2.5799,2.5799);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(164).to({_off:false},0).to({scaleX:2.58,scaleY:2.58,rotation:96.7401,guide:{path:[-532.2,-56.5,-530.5,-129.1,-510.7,-171.1]}},40).to({_off:true},1).wait(50));

	// Layer_6
	this.instance_2 = new lib.Symbol70();
	this.instance_2.setTransform(-453.6,-216.5,1.5499,1.5499,-97.732);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(119).to({_off:false},0).to({scaleX:1,scaleY:1,rotation:0,guide:{path:[-453.6,-216.4,-154.6,-257.8,0,0]}},45).wait(91));

	// Layer_1
	this.instance_3 = new lib.conicalflask2();
	this.instance_3.setTransform(-31.45,-55.25,0.1824,0.1824);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(204,204,204,0.557)").s().p("Ai2DbQhMgaAAgmIAAgFIB8l0IACAAQAIgIAagHQAlgIA0gBQA0ABAlAIQAaAHAIAIIABAAICQF0IAAADIAAACQAAAmhMAaQhMAbhrAAQhrAAhLgbg");
	this.shape.setTransform(1.275,24.5);

	this.instance_4 = new lib.Symbol70();
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_3}]}).to({state:[{t:this.instance_4}]},49).to({state:[{t:this.instance_4}]},70).to({state:[]},1).wait(135));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(49).to({_off:false},0).to({scaleX:1.5499,scaleY:1.5499,rotation:-97.732,guide:{path:[0,0,-154.6,-257.8,-453.6,-216.4]}},70).to({_off:true},1).wait(135));

	// Layer_3
	this.instance_5 = new lib.Symbol56();
	this.instance_5.setTransform(-2.7,-255.6);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({_off:false},0).to({scaleX:2.5799,scaleY:2.5799,guide:{path:[-2.7,-255.5,-372.6,-337.4,-533.6,-56.6]}},48).wait(115).to({_off:true},1).wait(90));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-680.4,-366.8,711.9,449.3);


(lib.Symbol43 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.cross = new lib.Symbol44();
	this.cross.name = "cross";

	this.timeline.addTween(cjs.Tween.get(this.cross).wait(1));

	// Layer_1
	this.instance = new lib.R1();
	this.instance.setTransform(-150,-100);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol43, new cjs.Rectangle(-150,-100,300,200), null);


(lib.Symbol25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_2
	this.instance = new lib.CachedBmp_30();
	this.instance.setTransform(-64.05,48.3,0.5,0.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(2));

	// Layer_1
	this.instance_1 = new lib.Handlens();
	this.instance_1.setTransform(-75,-60,0.24,0.24);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.078)").s().p("ANGNGI6PAAIgDAAIgIgBIgDAAIgBAAIgCAAQhugOAAh8IAA11QAAiICGgDIaFAAQCGADAACIIAAV1IAAACIAAAKIgBALIAAADIAAACQgEAggNAXIgBACIgBACIgBABIgBABIAAABIgBABIhnAwIgFAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1}]}).wait(3));

	// Layer_3
	this.clickedColor = new lib.Symbol31();
	this.clickedColor.name = "clickedColor";

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00FF66").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_1.setTransform(0.025,0.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_2.setTransform(0.075,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.clickedColor}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97.9,-84.8,195.9,169.7);


(lib.Symbol24 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_2
	this.instance = new lib.CachedBmp_29();
	this.instance.setTransform(-29.95,42.5,0.5,0.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(2));

	// Layer_1
	this.instance_1 = new lib.pipette();
	this.instance_1.setTransform(-138.2,3.5,0.22,0.22,-51);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.078)").s().p("As9NGQiLAAAAiLIAA11QAAiLCLAAIZ7AAQCLAAAACLIAAV1QAACLiLAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1}]}).wait(3));

	// Layer_4
	this.clickedColor = new lib.Symbol30();
	this.clickedColor.name = "clickedColor";

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00FF66").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_1.setTransform(0.075,0.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_2.setTransform(0.075,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.clickedColor}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-138.2,-85,246.6,230.1);


(lib.Symbol23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_2
	this.instance = new lib.CachedBmp_28();
	this.instance.setTransform(-43.5,43.2,0.5,0.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(2));

	// Layer_4
	this.instance_1 = new lib.Symbol69();
	this.instance_1.setTransform(0,0,0.29,0.29);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.078)").s().p("As9NGQiLAAAAiLIAA11QAAiLCLAAIZ7AAQCLAAAACLIAAV1QAACLiLAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3));

	// Layer_3
	this.clickedColor = new lib.Symbol33();
	this.clickedColor.name = "clickedColor";

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00FF66").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_1.setTransform(0.075,0.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_2.setTransform(0.075,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.clickedColor}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97.9,-84.8,195.9,169.7);


(lib.Symbol22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_2
	this.instance = new lib.CachedBmp_27();
	this.instance.setTransform(-54.1,40.25,0.5,0.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(2));

	// Layer_1
	this.instance_1 = new lib.new_therm();
	this.instance_1.setTransform(-47,-71,0.15,0.15);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.078)").s().p("As9NGQiLAAAAiLIAA11QAAiLCLAAIZ7AAQCLAAAACLIAAV1QAACLiLAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1}]}).wait(3));

	// Layer_3
	this.clickedColor = new lib.Symbol32();
	this.clickedColor.name = "clickedColor";

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00FF66").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_1.setTransform(0.025,0.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_2.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.clickedColor}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97.9,-84.8,195.9,169.7);


(lib.Symbol14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_2
	this.instance = new lib.CachedBmp_26();
	this.instance.setTransform(-42.9,44.5,0.5,0.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(2));

	// Layer_1
	this.instance_1 = new lib.mortar();
	this.instance_1.setTransform(-79,-70,0.2,0.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.078)").s().p("As9NGQiLAAAAiLIAA11QAAiLCLAAIZ7AAQCLAAAACLIAAV1QAACLiLAAg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1}]}).wait(3));

	// Layer_3
	this.clickedColor = new lib.Symbol34();
	this.clickedColor.name = "clickedColor";

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00FF66").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_1.setTransform(0.025,0.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_2.setTransform(0.075,0.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.clickedColor}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	// Layer_4
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.078)").s().p("As9NGQiLAAAAiLIAA11QAAiLCLAAIZ7AAQCLAAAACLIAAV1QAACLiLAAg");
	this.shape_3.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97.9,-84.8,195.9,169.8);


(lib.Symbol13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_2
	this.instance = new lib.CachedBmp_24();
	this.instance.setTransform(-39.45,52.6,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_25();
	this.instance_1.setTransform(-39.45,52.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).wait(1));

	// Layer_1
	this.instance_2 = new lib.tube();
	this.instance_2.setTransform(-142.75,-19.7,0.58,0.58,-54.0002);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3));

	// Layer_3
	this.clickedColor = new lib.Symbol29();
	this.clickedColor.name = "clickedColor";
	this.clickedColor.setTransform(0,5.45);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00FF66").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape.setTransform(0.025,5.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_1.setTransform(0.025,5.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.clickedColor}]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer_4
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.078)").s().p("As9NGQiLAAAAiLIAA11QAAiLCLAAIZ7AAQCLAAAACLIAAV1QAACLiLAAg");
	this.shape_2.setTransform(0.025,5.475);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-142.7,-123.4,280.4,252.70000000000002);


(lib.Symbol12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_2
	this.instance = new lib.CachedBmp_22();
	this.instance.setTransform(1.95,-24.3,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_23();
	this.instance_1.setTransform(1.95,-24.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).wait(1));

	// Layer_1
	this.instance_2 = new lib.Symbol68();
	this.instance_2.setTransform(-0.5,0.75,0.31,0.31);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3));

	// Layer_3
	this.clickedColor = new lib.Symbol28();
	this.clickedColor.name = "clickedColor";
	this.clickedColor.setTransform(10.7,3.65);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.039)").s().p("As9NGQiLAAAAiLIAA11QAAiLCLAAIZ7AAQCLAAAACLIAAV1QAACLiLAAg");
	this.shape.setTransform(10.725,3.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00FF66").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_1.setTransform(10.875,4.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_2.setTransform(10.875,4.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.clickedColor}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	// Layer_4
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.039)").s().p("As9NGQiLAAAAiLIAA11QAAiLCLAAIZ7AAQCLAAAACLIAAV1QAACLiLAAg");
	this.shape_3.setTransform(10.725,3.675);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87.2,-81.1,196,170.1);


(lib.Symbol11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_2
	this.instance = new lib.CachedBmp_20();
	this.instance.setTransform(-50.35,49.9,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_21();
	this.instance_1.setTransform(-50.35,49.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).wait(1));

	// Layer_1
	this.conical_MC = new lib.Symbol67();
	this.conical_MC.name = "conical_MC";
	this.conical_MC.setTransform(-0.05,-0.05,0.3,0.3,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.conical_MC).wait(3));

	// Layer_3
	this.clickedColor = new lib.Symbol27();
	this.clickedColor.name = "clickedColor";

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.039)").s().p("As9NGQiLAAAAiLIAA11QAAiLCLAAIZ7AAQCLAAAACLIAAV1QAACLiLAAg");
	this.shape.setTransform(0.025,0.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00FF66").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_1.setTransform(0.025,0.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_2.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.clickedColor}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	// Layer_4
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.039)").s().p("As9NGQiLAAAAiLIAA11QAAiLCLAAIZ7AAQCLAAAACLIAAV1QAACLiLAAg");
	this.shape_3.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97.9,-90.9,195.9,181.8);


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_19();
	this.instance.setTransform(-134.85,-186.85,0.5,0.5);

	this.retry_2 = new lib.Symbol5();
	this.retry_2.name = "retry_2";
	this.retry_2.setTransform(77.25,248.25);
	new cjs.ButtonHelper(this.retry_2, 0, 1, 1);

	this.instance_1 = new lib.CachedBmp_18();
	this.instance_1.setTransform(-115.6,-248.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_17();
	this.instance_2.setTransform(-159.5,-279.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.retry_2},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-159.5,-279.8,319,560);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_14();
	this.instance.setTransform(-134.85,-96.2,0.5,0.5);

	this.partial_text = new cjs.Text("Some of the apparatus you selected are not appropriate for the experment.", "16px 'Verdana'");
	this.partial_text.name = "partial_text";
	this.partial_text.lineHeight = 21;
	this.partial_text.lineWidth = 278;
	this.partial_text.parent = this;
	this.partial_text.setTransform(-132.85,-184.85);

	this.retry_1 = new lib.Symbol5();
	this.retry_1.name = "retry_1";
	this.retry_1.setTransform(77.25,248.25);
	new cjs.ButtonHelper(this.retry_1, 0, 1, 1);

	this.instance_1 = new lib.CachedBmp_13();
	this.instance_1.setTransform(-115.6,-248.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.retry_1},{t:this.partial_text},{t:this.instance}]}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D4A314").s().p("AzfESQizAAAAizIAAi9QAAizCzAAMAm/AAAQCzAAAACzIAAC9QAACzizAAg");
	this.shape.setTransform(4.525,-234.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FCEDC1").s().p("EgVaArvQhdAAhChCQhBhBAAhdMAAAhQdQAAhdBBhBQBChCBdAAMAq1AAAQBdAABCBCQBBBBAABdMAAABQdQAABdhBBBQhCBChdAAgEgVlgmIIAAC/QAACzCzAAMAm/AAAQCzAAAAizIAAi/QAAizizAAMgm/AAAQizAAAACzg");
	this.shape_1.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-159.5,-279.8,319.1,559.7), null);


(lib.Symbol8_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_2
	this.instance_3 = new lib.CachedBmp_10();
	this.instance_3.setTransform(-33.35,52.35,0.5,0.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).wait(2));

	// Layer_3
	this.beaker_MC = new lib.Symbol65();
	this.beaker_MC.name = "beaker_MC";
	this.beaker_MC.setTransform(0,0.05,0.38,0.38,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.beaker_MC).wait(3));

	// Layer_1
	this.clickedColor = new lib.Symbol26();
	this.clickedColor.name = "clickedColor";

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00FF66").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape.setTransform(0.025,0.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(2,1,1).p("As9tFIZ7AAQCLAAAACLIAAV1QAACLiLAAI57AAQiLAAAAiLIAA11QAAiLCLAAg");
	this.shape_1.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.clickedColor}]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer_4
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.078)").s().p("As9NGQiLAAAAiLIAA11QAAiLCLAAIZ7AAQCLAAAACLIAAV1QAACLiLAAg");
	this.shape_2.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97.9,-84.8,195.9,169.7);


(lib.animation_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_274 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(274).call(this.frame_274).wait(1));

	// Layer_19
	this.instance = new lib.Symbol56();
	this.instance.setTransform(-473.5,64.35,2.35,2.35,99.1983);
	this.instance._off = true;

	this.ani1_cyl = new lib.Symbol56();
	this.ani1_cyl.name = "ani1_cyl";
	this.ani1_cyl.visible = false;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},229).to({state:[{t:this.ani1_cyl}]},45).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(229).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1,rotation:0,guide:{path:[-473.4,64.3,-244,-52.5,0,-0.2]},visible:false},45).wait(1));

	// Layer_16
	this.instance_1 = new lib.Symbol56();
	this.instance_1.setTransform(-528.85,155.05,2.3499,2.3499,40.5813);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(203).to({_off:false},0).wait(1).to({scaleX:2.35,scaleY:2.35,rotation:42.8365,x:-527.95,y:151},0).wait(1).to({scaleX:2.3499,scaleY:2.3499,rotation:45.09,x:-526.95,y:146.95},0).wait(1).to({rotation:47.3457,x:-525.95,y:142.95},0).wait(1).to({rotation:49.5995,x:-524.85,y:138.9},0).wait(1).to({scaleX:2.35,scaleY:2.35,rotation:51.853,x:-523.65,y:134.95},0).wait(1).to({scaleX:2.3499,scaleY:2.3499,rotation:54.1085,x:-522.4,y:130.95},0).wait(1).to({scaleX:2.35,scaleY:2.35,rotation:56.363,x:-521.05,y:127},0).wait(1).to({scaleX:2.3499,scaleY:2.3499,rotation:58.6182,x:-519.65,y:123.1},0).wait(1).to({scaleX:2.35,scaleY:2.35,rotation:60.8718,x:-518.1,y:119.2},0).wait(1).to({rotation:63.1271,x:-516.5,y:115.35},0).wait(1).to({rotation:65.381,x:-514.75,y:111.55},0).wait(1).to({rotation:67.6365,x:-512.9,y:107.75},0).wait(1).to({scaleX:2.3499,scaleY:2.3499,rotation:69.8909,x:-510.95,y:104.05},0).wait(1).to({scaleX:2.35,scaleY:2.35,rotation:72.1455,x:-508.85,y:100.4},0).wait(1).to({scaleX:2.3499,scaleY:2.3499,rotation:74.4,x:-506.65,y:96.8},0).wait(1).to({scaleX:2.35,scaleY:2.35,rotation:76.653,x:-504.3,y:93.3},0).wait(1).to({rotation:78.9088,x:-501.8,y:89.85},0).wait(1).to({scaleX:2.3499,scaleY:2.3499,rotation:81.1629,x:-499.2,y:86.5},0).wait(1).to({scaleX:2.35,scaleY:2.35,rotation:83.4183,x:-496.45,y:83.3},0).wait(1).to({rotation:85.6721,x:-493.55,y:80.2},0).wait(1).to({rotation:87.9269,x:-490.5,y:77.25},0).wait(1).to({rotation:90.1801,x:-487.25,y:74.5},0).wait(1).to({rotation:92.4353,x:-483.9,y:71.8},0).wait(1).to({rotation:94.6895,x:-480.45,y:69.35},0).wait(1).to({rotation:96.9443,x:-476.9,y:67},0).wait(1).to({rotation:99.1983,x:-473.5,y:64.35},0).to({_off:true},1).wait(45));

	// Layer_11
	this.instance_2 = new lib.Symbol60();
	this.instance_2.setTransform(-536.35,229.05);
	this.instance_2._off = true;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFE0").s().p("AlJByIFcmWIEfA1QALAQANgJInCINQiahOg3hlg");
	this.shape.setTransform(-556.525,219.4625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFE0").s().p("AmnCaIF7mYIHUhWIjeDhIgCgBImnHIQiXhUgxhmg");
	this.shape_1.setTransform(-549.05,209.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFE0").s().p("AmsCQIGdmaICLgQIARAQIAAgRQB+ADAzgWQBKg/AlAzIqXKMQiUhaguhog");
	this.shape_2.setTransform(-550.5125,203.4416);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFE0").s().p("AnYCfIHUmuIBkgMQgaASAaAUIAAgmIAAgBQBag1BBAiQBeAuAOg7QBdhPAVBAIkdEAIAAgBInbG1QiPhggqhqg");
	this.shape_3.setTransform(-547.825,195.237);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFE0").s().p("AnaB4IG7l5ICBgNQBJA4AqhEQEWhBgRAbIklD1IgBgBIndGVQiMhlglhsg");
	this.shape_4.setTransform(-549.1419,192.3123);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFE0").s().p("An9B4IHzmHIA6gHIABABIgBgBQB8hiBKBKQDVAHAzgmIlhEWIAAABInwGFQiIhqgihtg");
	this.shape_5.setTransform(-547.0125,185.5479);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFE0").s().p("AnpBUIHxlnIB4AAQAMgeAjAeQB8AbAPgPQAEgEgEgIQC/g9gQA9IkcDJIgDgDIoTF/QiDhwgdhug");
	this.shape_6.setTransform(-550.1238,182.1037);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFE0").s().p("An4BGIIKlbIBEAAQC0goAXAoQCtAYArgRItZI4Qh/h1gZhvgADGh7QACAaAIAJQAOglgngVgAC1iTQgJgFgMgDQAKAMALgEg");
	this.shape_7.setTransform(-549.55,176.5231);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFE0").s().p("AohA2IGBjqIEEglQCQAFAMgcQEog+gGAVIl7DeIAAAAIo5FbQh6h6gVhwgACAiRQgCgNgMgPQAGATAIAJg");
	this.shape_8.setTransform(-546.2182,171.0838);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFE0").s().p("AoLAaIF8jSIEXgZQAhAVCUgkQDNhFACAzIlQC6IAAAAIpCFBQh1h+gQhxg");
	this.shape_9.setTransform(-548.925,166.7861);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFE0").s().p("ApCAUIFPipIB3gPQClAEAxgfQAEAdAGATIgEgxQDohAAeAgQEOg+g7AjIv/IEQhxiDgLhyg");
	this.shape_10.setTransform(-543.684,160.1983);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFE0").s().p("AptAOIEZh/IA/gJQCZg9BuAWIBFgKQDggHA/gkQEwhDgbAaIxmIGQhqiHgIhyg");
	this.shape_11.setTransform(-539.4944,153.5662);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFE0").s().p("AqTgCIFAiEICqgTQCIAKAzggIAFAMQACAfAFATIgDg/QDAhcBXA8QDNAICVgxIsLFAIAAAAIgKAEIgDABIgMAFImbCpQhliMgDhwg");
	this.shape_12.setTransform(-535.4,148.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFE0").s().p("AqqgUIGxieID/gDQAKgBAWABIAbgMQEQhBAcAzQEcgwAiAgIz2HMQhgiQABhxg");
	this.shape_13.setTransform(-532.7136,142.6076);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFE0").s().p("Ar9gbIH5ijICigFQCnAUBBgbQDFgfARAQIAAAIQB6ASAGgWQEvgggNAXItzERIAAAAIo0C2QhbiTAHhxg");
	this.shape_14.setTransform(-523.6087,136.1388);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFE0").s().p("AtEglIDohBIDWgRQCPAHBngbIAjgDQC7g4B5AeIAAAAQCdASBbgnQF8gtALAMI5AG/QhUiWAKhwg");
	this.shape_15.setTransform(-515.6282,129.9658);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFE0").s().p("AuUgvIDOgxIBtgHQDcAXBjgtIA5gEQEYgxA4AZQEZgCA4gVQF8g8BbAcI7rGqQhPiZAPhwg");
	this.shape_16.setTransform(-506.3203,123.7683);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFE0").s().p("AwPg7IDhgsICPgGQB4giBLAZIB+gGQDsgrBUAdQFmAVBpgqQG6hKCnAmIADAMI6HFBIgJACIlgBFQhIicAUhwg");
	this.shape_17.setTransform(-492.3662,117.7933);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFE0").s().p("AwQhZIK5gZQCUAOCGgXQDvgiBAAXQC/AUBSgdQDBgVA/AMQCWgyBjApQANAGAJAHIAFAYI3gDeIAAgBIodBUQhCifAYhvg");
	this.shape_18.setTransform(-490.545,113.7286);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFE0").s().p("AwOhmQDOgWDTAPIEegFQCoAlBggqQCYANBJgQQDjghB3AbQGngnBwAeIAJA6I/+DmQg3iVAThog");
	this.shape_19.setTransform(-489.0364,109.8327);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFE0").s().p("AwOhoQFcAbBwgbQDogQAOAQIAdAAQBvAMBYgMIATAAQB5guAgAuQEqAOAQgOQC3gyBaAyQEYgkBcAkQAXBIgLAMMggAACWQgtiHAQhjg");
	this.shape_20.setTransform(-487.0153,105.1273);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFE0").s().p("AwKhqILBAAQAugHApgDIDvAMQBlALBSgBQFrAwEJAEIAPAAQDCAGATAfQAGAhgGAII3TBAIAAgCIotAUQgliCAPheg");
	this.shape_21.setTransform(-485.1091,99.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFE0").s().p("Av3B2QgiiLAYhhQGCBTE+gYIBNAGQC7A4A0gkQD/gPAcAnQCUAxA3ghQHTBMBIgMQAgAtggADg");
	this.shape_22.setTransform(-482.8545,93.15);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFE0").s().p("AloA8IgBAAIqNgbQgQhPABhCQClArBvgSQBgAEBQAFIBuAHQCfANBEASQGTBFDxgMQHzA9B2gFQAOAjgJAFg");
	this.shape_23.setTransform(-480.6638,95.0625);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFE0").s().p("Av1gEQgOhVAGhEQDUA+CzgKQHsAkDDA4QFMBUCdgUQGYAeA1AfQAiArgjADg");
	this.shape_24.setTransform(-478.2981,92.4875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFE0").s().p("APlDHI/Wj5QgJhSAHhCQGJBrEoAQIFLA8QFuAfBuA1QG5AjBPA7QAWAkgZAAIgFAAg");
	this.shape_25.setTransform(-476.0393,90.8259);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFE0").s().p("ApCgrIhFgLIlmg6QgEg3ADgwQCaA+EUAVQDzAZAQAZQBtA9BtgTQH5BFA1AbIAAAKQGLAuCTA6QAOAggOAOg");
	this.shape_26.setTransform(-473.6856,90.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},185).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[]},1).wait(45));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(185).to({_off:false},0).wait(1).to({rotation:2.2536,x:-536.25,y:224.8},0).wait(1).to({rotation:4.5089,x:-536.15,y:220.7},0).wait(1).to({rotation:6.7625,x:-536,y:216.6},0).wait(1).to({rotation:9.0178,x:-535.8,y:212.5},0).wait(1).to({rotation:11.272,x:-535.55,y:208.4},0).wait(1).to({rotation:13.5271,x:-535.3,y:204.3},0).wait(1).to({rotation:15.781,x:-535,y:200.15},0).wait(1).to({rotation:18.0363,x:-534.7,y:196.05},0).wait(1).to({rotation:20.2901,x:-534.3,y:191.95},0).wait(1).to({rotation:22.5451,x:-533.9,y:187.85},0).wait(1).to({rotation:24.7991,x:-533.45,y:183.7},0).wait(1).to({rotation:27.0534,x:-532.95,y:179.6},0).wait(1).to({rotation:29.3085,x:-532.4,y:175.5},0).wait(1).to({rotation:31.5623,x:-531.8,y:171.45},0).wait(1).to({rotation:33.8181,x:-531.15,y:167.35},0).wait(1).to({rotation:36.0717,x:-530.45,y:163.3},0).wait(1).to({rotation:38.3275,x:-529.7,y:159.2},0).to({_off:true},1).wait(72));

	// Layer_18
	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,224,0.498)").s().p("AAdO8IBLAAQgehPhAiKIA7AAQgMhKhGjDQAnAtABgtQABg7hBjaQAQAKAHgMQAVgohIkHIgXkEQAFhngXhtIAAAAQhyuxCDOvQAoC1gHAZIgHABQABDBAgA/QAwD/ACA2IgLACQAnDEAOBWIgRAAIALAlQA0CtAHA7IgkAAQA6CXAQBCQAaBnhIhnIgDAAIAFAOIALBYQgWgJhFhdg");
	this.shape_27.setTransform(-373.0457,204.3199);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,224,0.498)").s().p("AAPO/IBKAAQgehPg/iKIA6AAQgMhKhGjDQAnAtABgtQABg7hBjaQAQAKAHgMQAWgohIkHIgXkEQAEhngXhtIAAAAQg2u9BHO7QAoC1gHAZIgHABQABDBAgA/QAwD/ACA2IgKACQAmDEAOBWIgRAAIALAlQA0CtAHA7IgjAAQA5CXAQBCQAaBnhIhnIgDAAIAFAOIALBYQgWgJhEhdg");
	this.shape_28.setTransform(-371.5563,204.0227);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,224,0.498)").s().p("AALPAIBLAAQgehOg/iKIA6AAQgMhKhGjDQAnAtABgtQABg8hBjZQAQAJAHgMQAWgohJkHIgXkEQAFhngXhtIAAAAQgpvCA6PAQAoC1gHAZIgHACQABDAAgA/QAwEAACA2IgKABQAmDFAOBWIgRAAIALAkQA0CtAHA8IgkAAQA5CWARBCQAaBnhIhnIgDAAIAFAOIALBYQgWgJhFhdg");
	this.shape_29.setTransform(-371.2339,203.8908);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,224,0.498)").s().p("AAEPSIBKAAQgehPg/iKIA6AAQgMhKhGjDQAnAtABgtQACg8hCjZQAQAJAHgMQAXgnhJkIIgXkEQAEhmgXhtIAAAAQgHwIAYQFQAoC1gHAZIgHACQABDAAgBAQAxD/ACA2IgLABQAmDFAOBWIgRAAIALAlQA0CtAHA7IgjAAQA5CXAQBCQAbBmhJhmIgDAAIAFAOIALBYQgVgKhFhcg");
	this.shape_30.setTransform(-370.4746,202.1475);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,224,0.498)").s().p("AADO3IBKAAQgehPg+iKIA5AAQgMhKhFjDQAnAtABgtQABg7hCjaQAQAKAIgMQAWgohJkHIgXkEQAEhngXhtIABAAQAYruAKHQQAJHRAHAZIgHABQBOGvgtivQAxD/ABA2IgLACQAnDEAOBWIgRAAIALAlQA0CtAGA7IgjAAQA5CXARBCQAaBnhIhnIgEAAIAGAOIALBYQgWgJhFhdg");
	this.shape_31.setTransform(-370.4029,204.8127);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,224,0.498)").s().p("AADOqIBKAAQgehOg+iKIA5AAQgMhKhFjDQAnAtABgtQABg8hCjZQAQAJAIgMQAWgohJkHIgXkEQAEhngXhtIABAAQAzrIgGG/QgHG/AMAWIgHACQBIGagnibQAxEAABA2IgLABQAnDFAOBWIgRAAIALAkQA0CtAGA8IgjAAQA5CWARBCQAaBnhIhnIgEAAIAGAOIALBYQgWgJhFhdg");
	this.shape_32.setTransform(-370.4029,206.0907);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,224,0.498)").s().p("AgVOpIBJAAQgehPg+iKIA5AAQgLhKhGjDQAoAtABgtQABg7hDjaQARAKAHgMQAWgohJkHIgXkEQAEhngXhtIABAAQAXkrAOiIIAaAAIgBBVQgGIRgGAZIgHABQBvHKhDisQCTGVhsh+IgLACQDOIkiZkKIAhCuQAQBAADAfIBgCSIg5BFIgDgOIADAQQAaBnhIhnIgEAAIAGAOIALBYQgWgJhEhdg");
	this.shape_33.setTransform(-367.9125,206.2125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,224,0.498)").s().p("Ag0OOIBJAAQgdhPg/iKIA6AAQgMhKhGjDQAoAtABgtQABg7hDjaQARAKAHgNQAWgnhJkIIgXkEQAEhmgXhtIABAAQBZqBgFG2QgEG3geghIgHACQCEJEhbknQB+G9hUilIgLABQDVJLifkwIgRAAQALAgCXE6QCYE6jRi4IgCgGIAEAQQAaBmhIhmIgEAAIAGAOIALBYQgWgJhEhdg");
	this.shape_34.setTransform(-364.8102,208.9358);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,224,0.498)").s().p("Ag0OFIBJAAQgdhOg/iKIA6AAQgMhKhGjDQAoAtABgtQABg8hDjZQARAJAHgMQAWgohJkHIgXkEQAEhngXhtIABAAQBvprgJGyQgKGyADDAQA6EOhFjcQB+G8hUikIgLABQDVJKifkvIgRAAQALAfCXE6QCYE6jRi4IgCgFIAEAPQAaBnhIhnIgEAAIAGAOIALBYQgWgJhEhdg");
	this.shape_35.setTransform(-364.8102,209.7779);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,224,0.498)").s().p("AhHORIBKAAIAFAOIALBYQgVgJhFhdgABENNIgBgFIAEAPQAaBnhIhnIgEAAQgdhPg/iKIA6AAQgMhKhGjDQAnAtABgtQACg7hDjaQAQAKAHgMQAXgohJkHIgXkEQAEhngXhtQAtj7AahOIAeALQADAtgCBYQgJGyADC/QA5EPhEjdQB9G9hTilIgLACQDUJKifkwIgRAAQAMAgCXE6QBfDGgvAAQgcAAhOhEg");
	this.shape_36.setTransform(-362.9416,208.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_27}]},220).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[]},1).wait(45));

	// Layer_17
	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,224,0.498)").s().p("AoUDAQh8hqgdiVIAAhSQJ5j7KBCzQAwAQAxATIAABVQgSD8izBDQj7BGjrAAQkWAAkBhkg");
	this.shape_37.setTransform(-337.45,321.204);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,224,0.498)").s().p("AoUDGQh8hqgdiWIAAhcQKpkOKyDkIAABkQgSD8izBDQj7BGjrAAQkWAAkBhjg");
	this.shape_38.setTransform(-337.45,320.6776);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,224,0.498)").s().p("AoUDOQh8hqgdiVIAAhuQKpkOKyDkIAAB2QgSD8izBDQj7BGjrAAQkWAAkBhkg");
	this.shape_39.setTransform(-337.45,319.8026);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,224,0.498)").s().p("AoUDXQh8hqgdiVIAAh/QKpkOKyDjIAACIQgSD8izBDQj7BGjrAAQkWAAkBhkg");
	this.shape_40.setTransform(-337.45,318.9276);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,224,0.498)").s().p("AoUDgQh8hqgdiVIAAiRQKpkOKyDjIAACaQgSD7izBDQj7BHjrAAQkWAAkBhkg");
	this.shape_41.setTransform(-337.45,318.0526);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,224,0.498)").s().p("AoUDpQh8hqgdiWIAAiiQKpkOKyDkIAACqQgSD8izBDQj7BGjrAAQkWAAkBhjg");
	this.shape_42.setTransform(-337.45,317.1776);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,224,0.498)").s().p("AoUDxQh8hqgdiVIAAi0QKpkOKyDkIAAC8QgSD8izBDQj7BGjrAAQkWAAkBhkg");
	this.shape_43.setTransform(-337.45,316.3026);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,224,0.498)").s().p("AoUD6Qh8hqgdiVIAAjFQKpkOKyDjIAADOQgSD8izBDQj7BGjrAAQkWAAkBhkg");
	this.shape_44.setTransform(-337.45,315.4276);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,224,0.498)").s().p("AoUEDQh8hqgdiWIAAjWQKpkOKyDjIAADgQgSD7izBDQj7BHjrAAQkWAAkBhkg");
	this.shape_45.setTransform(-337.45,314.5526);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,224,0.498)").s().p("AoUEMQh8hqgdiXIAAjnQKpkOKyDkIAADwQgSD8izBDQj7BGjrAAQkWAAkBhjg");
	this.shape_46.setTransform(-337.45,313.6776);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_37}]},220).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).wait(46));

	// Layer_6
	this.instance_3 = new lib.conicalflask2();
	this.instance_3.setTransform(-523.8,126.9,0.3077,0.3077,-104.9982);
	this.instance_3._off = true;

	this.instance_4 = new lib.Symbol57();
	this.instance_4.setTransform(-380.1,28,0.46,0.46,0,0,0,0,0.2);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(119).to({_off:false},0).wait(1).to({scaleX:0.3059,scaleY:0.3059,rotation:-100.7987,x:-526.15,y:119.55},0).wait(1).to({scaleX:0.3041,scaleY:0.3041,rotation:-96.5958,x:-527.85,y:111.9},0).wait(1).to({scaleX:0.3023,scaleY:0.3023,rotation:-92.3957,x:-529.05,y:104},0).wait(1).to({scaleX:0.3004,scaleY:0.3004,rotation:-88.2014,x:-529.65,y:95.95},0).wait(2).to({scaleX:0.2986,scaleY:0.2986,rotation:-84.0019,x:-529.8,y:87.65},0).wait(1).to({scaleX:0.2968,scaleY:0.2968,rotation:-79.8011,x:-529.35,y:79.3},0).wait(1).to({scaleX:0.295,scaleY:0.295,rotation:-75.6015,x:-528.4,y:70.85},0).wait(1).to({scaleX:0.2913,scaleY:0.2913,rotation:-67.201,x:-524.7,y:53.85},0).wait(1).to({scaleX:0.2895,scaleY:0.2895,rotation:-63.0027,x:-521.95,y:45.4},0).wait(1).to({scaleX:0.2877,scaleY:0.2877,rotation:-58.7981,x:-518.7,y:37.05},0).wait(1).to({scaleX:0.2858,scaleY:0.2858,rotation:-54.5996,x:-514.9,y:28.8},0).wait(1).to({scaleX:0.284,scaleY:0.284,rotation:-50.4017,x:-510.6,y:20.75},0).wait(1).to({scaleX:0.2822,scaleY:0.2822,rotation:-46.2006,x:-505.7,y:12.9},0).wait(1).to({scaleX:0.2804,scaleY:0.2804,rotation:-41.9979,x:-500.4,y:5.2},0).wait(1).to({scaleX:0.2785,scaleY:0.2785,rotation:-37.799,x:-494.65,y:-2.05},0).wait(1).to({scaleX:0.2767,scaleY:0.2767,rotation:-33.5989,x:-488.3,y:-9.1},0).wait(1).to({scaleX:0.2749,scaleY:0.2749,rotation:-29.3966,x:-481.65,y:-15.9},0).wait(1).to({scaleX:0.2731,scaleY:0.2731,rotation:-25.1991,x:-474.5,y:-22.3},0).wait(1).to({scaleX:0.2713,scaleY:0.2713,rotation:-20.9982,x:-467.05,y:-28.25},0).wait(1).to({scaleX:0.2694,scaleY:0.2694,rotation:-16.7981,x:-459.3,y:-33.75},0).wait(1).to({scaleX:0.2676,scaleY:0.2676,rotation:-12.5972,x:-451.2,y:-38.9},0).wait(1).to({scaleX:0.2658,scaleY:0.2658,rotation:-8.398,x:-442.8,y:-43.55},0).wait(1).to({scaleX:0.264,scaleY:0.264,rotation:-4.1965,x:-434.15,y:-47.75},0).to({_off:true},1).wait(130).to({_off:false,scaleX:0.1824,scaleY:0.1824,rotation:0,x:-28.35,y:76.2},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(144).to({_off:false},0).wait(1).to({regY:0.4,scaleX:0.4565,scaleY:0.4565,x:-370.15,y:25.65},0).wait(1).to({regY:0.2,scaleX:0.4529,scaleY:0.4529,x:-360.15,y:23.4},0).wait(1).to({scaleX:0.4494,scaleY:0.4494,x:-350.1,y:21.55},0).wait(1).to({regX:-0.1,scaleX:0.446,scaleY:0.446,x:-340,y:19.9},0).wait(1).to({regY:0.4,scaleX:0.4424,scaleY:0.4424,x:-329.85,y:18.6},0).wait(1).to({regY:0.2,scaleX:0.4389,scaleY:0.4389,x:-319.6,y:17.4},0).wait(1).to({regX:0,scaleX:0.4355,scaleY:0.4355,x:-309.3,y:16.65},0).wait(1).to({scaleX:0.4319,scaleY:0.4319,x:-299,y:16.15},0).wait(1).to({regY:0.4,scaleX:0.4285,scaleY:0.4285,x:-288.7,y:15.9},0).wait(1).to({regX:-0.1,regY:0.2,scaleX:0.425,scaleY:0.425,x:-278.4},0).wait(1).to({scaleX:0.4214,scaleY:0.4214,x:-268.1,y:16.3},0).wait(1).to({scaleX:0.418,scaleY:0.418,x:-257.75,y:16.95},0).wait(1).to({regY:0.4,scaleX:0.4144,scaleY:0.4144,x:-247.45,y:17.9},0).wait(1).to({regX:0,regY:0.2,scaleX:0.4109,scaleY:0.4109,x:-237.1,y:19.1},0).wait(1).to({scaleX:0.4075,scaleY:0.4075,x:-226.85,y:20.65},0).wait(1).to({scaleX:0.4039,scaleY:0.4039,x:-216.65,y:22.45},0).wait(1).to({regX:-0.1,regY:0.4,scaleX:0.4005,scaleY:0.4005,x:-206.55,y:24.5},0).wait(1).to({regY:0.2,scaleX:0.397,scaleY:0.397,x:-196.45,y:26.8},0).wait(1).to({scaleX:0.3934,scaleY:0.3934,x:-186.45,y:29.45},0).wait(1).to({regX:0,scaleX:0.39,scaleY:0.39,x:-176.4,y:32.35},0).wait(1).to({regY:0.4,scaleX:0.3865,scaleY:0.3865,x:-166.55,y:35.45},0).wait(1).to({regY:0.2,scaleX:0.3829,scaleY:0.3829,x:-156.7,y:38.75},0).wait(1).to({regX:-0.1,scaleX:0.3795,scaleY:0.3795,x:-147.05,y:42.4},0).wait(1).to({scaleX:0.376,scaleY:0.376,x:-137.4,y:46.25},0).wait(1).to({scaleX:0.3724,scaleY:0.3724,x:-127.9,y:50.15},0).wait(1).to({regX:0,scaleX:0.369,scaleY:0.369,x:-118.4,y:54.4},0).wait(1).to({scaleX:0.3655,scaleY:0.3655,x:-109.05,y:58.9},0).wait(1).to({regY:0.3,scaleX:0.3619,scaleY:0.3619,x:-99.85,y:63.6},0).wait(1).to({regX:-0.1,scaleX:0.3585,scaleY:0.3585,x:-90.75,y:68.4},0).wait(1).to({scaleX:0.355,scaleY:0.355,x:-81.7,y:73.4},0).wait(1).to({scaleX:0.3514,scaleY:0.3514,x:-72.8,y:78.6},0).wait(1).to({regX:0,scaleX:0.348,scaleY:0.348,x:-63.9,y:83.95},0).wait(1).to({scaleX:0.3445,scaleY:0.3445,x:-55.2,y:89.4},0).wait(1).to({scaleX:0.3409,scaleY:0.3409,x:-46.55,y:95.05},0).wait(1).to({regX:-0.1,scaleX:0.3375,scaleY:0.3375,x:-38.1,y:100.85},0).wait(1).to({scaleX:0.334,scaleY:0.334,x:-29.65,y:106.75},0).wait(1).to({scaleX:0.3304,scaleY:0.3304,x:-21.35,y:112.75},0).wait(1).to({regX:0,scaleX:0.327,scaleY:0.327,x:-13.05,y:118.95},0).wait(1).to({scaleX:0.3235,scaleY:0.3235,x:-4.95,y:125.25},0).wait(1).to({regY:0.1,scaleX:0.32,scaleY:0.32,x:3.1,y:131.55},0).to({_off:true},90).wait(1));

	// Layer_10
	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFE0").s().p("ArYCxQBXiNC4BDQEmgSAVhDQByihDPBKQDvAHAIhKQAkg0AngcQA3gnA+AIQAsAFAwAcQAZB+gIBlQgLCIg+AQIgHACIk5gSIABACIphgkImyCGg");
	this.shape_47.setTransform(-437.0079,57.7548);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFE0").s().p("AHMC0IgYgEIiAgRIgTgCIgcgEIgsgFIhYgLIgWgDIhCgJIAAABIkxgmInLBmIgLg3QCiAhBJhXQB/h9DQAvQD6AiBBhqQAcgDAYgGQASgFAQgGQAZgJAUgMQAlgRAmgOQBcgiBcgPQBbgPBbAEQAWCRgSBwQgUCGg/AMIgHABg");
	this.shape_48.setTransform(-435.8744,58.3007);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFE0").s().p("AJoDPIkrg+IABACIpyhvImgA+IgJhFQCtAjCuhNIAYgLQBqgtBbgMQBpgOBVAgQD/A2C9htQAPgQAPgNQB0hoBhBQQALAJAKAMQAGB7gXBfQgeCDg/AIIgDAAIgEAAg");
	this.shape_49.setTransform(-433.8121,61.8337);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFE0").s().p("AJRDlIlVhhIAAAAIobiQIm6AbIgFgwIAigSQCBhDBJgBQA+gCAWAtQEvBlAchRQAIgYgPgnQBQgkBBgYQBAgXAzgLQCfglAqBGQFDBnAniXIABAWQAICzgoB+QgnB/g/ADIgHAAg");
	this.shape_50.setTransform(-431.9027,63.2875);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFE0").s().p("AI4DZIgHgBIpYjbIAAADIjUhKIABgKIneAAIAAgyQCihPByBPQEtAnBdgnQDvhSBoBSQCxB1BEh1QAhgiAbgTQBXg/AlBJQAJASAGAZQgLCEgnBhQgvB6g+AAIgCAAg");
	this.shape_51.setTransform(-429.425,68.0215);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFE0").s().p("AIkDlIgHgCIoej0IAAABIkPh4InEgXIAFhFQBxAzCZgVQCPgrB9BKQCOBrCVhKQAggLAfgGQAtgJAqADQBVAFBGA1QB6BtDAhJQgVBlglBOQg2Bxg7AAIgGAAg");
	this.shape_52.setTransform(-428.4875,70.0668);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFE0").s().p("AH4EgIgHgCIoIkbIAAACIkpiNImTgrIANhoQDdgVCrBLQCbBSCqgmQDUgYBZBBQDtB6CzhCQgfCjhABuQg6Bng4AAIgLAAg");
	this.shape_53.setTransform(-425.35,67.1496);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFE0").s().p("AHWEvIgGgCIoXlXIABgFQgEgHgCgMIgFATIiphkInah6IAIgiQB4A1CxgJQCNgPBsAzQCSBPBhgqQC4gUCdBGQCYBoCfg6IgGAWIAAACQgrCohJBsQg/Beg2AAQgIAAgIgBg");
	this.shape_54.setTransform(-423.6375,68.2473);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFE0").s().p("AGcFbIgGgCIqanyIh0gkIlbh3IAPgqIAMABQCBA3C1giIAjAGQDRALC2A1QCPBjCOg0QDrgsCkBuQgNBFgaBMQg3CjhQBmQhDBWgzAAQgKAAgKgEg");
	this.shape_55.setTransform(-419.575,66.1133);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFE0").s().p("AFoGFIgFgDInPmkIiziVImminIARgrIA/gBIAlAFQAzBHCcgSQA6gIAwADQAtACAlANQA9AUApAtQDTBzCSgYQEngkCYCXQgSA9geBDQhFCchZBcQhFBKgxAAQgNAAgMgGg");
	this.shape_56.setTransform(-417,64.6762);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFE0").s().p("AE0GcIgGgDIm3m8IirifImci8IAJgVQCTgrB6BTQCeBRBvgpQCqgmBrBQQDYBsB9g5QCSgtCCBWIgCAXQgEAbgGAcQgGAbgJAdQgYBPgtBYQhOCYhcBXQhHBEgwAAQgPAAgNgHg");
	this.shape_57.setTransform(-413.275,63.2229);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFE0").s().p("AD2GkIgFgDImSnXIgKAAIi3jFIlZixIDCAJQBAAoBdgGQBEADA8AGIBiAPQB+AZBPAzQDnBnCZgPQCigbBHBRIgEAUQgHAigMAjQgOAsgWAtQgYA2gjA5QhXCRhjBQQhHA6guAAQgSAAgPgJg");
	this.shape_58.setTransform(-409.425,63.6434);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFE0").s().p("AAWFfIgFgEIlhniIgTAAIimjMQA7A5DHgsQCjhQDZBjQB4gOB5AMICcAZQASAqgZBYIgHAZIgGARQgmBnhRBxQhhCJhoBIQhGAygtAAQgVAAgQgMg");
	this.shape_59.setTransform(-389.3936,71.4608);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFE0").s().p("Ag/FAIgEgFIjOlHIgNgUIg0hTIgagpIhxiwQBigDB3AUQBwAkDQgLQDNgDDVAkIgBAHIgDABQABANgCAOIgBALIgDALQgFAZgKAdQgJAXgLAXQgsBhhWBnQhqCBhtBAQhEAogqABQgZAAgRgOg");
	this.shape_60.setTransform(-383.25,75.1351);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFE0").s().p("AiNEgIgFgFIkdoaIADgDIABgJQCEgSCDAGQDcAICLgYIC+gJIAXAJIADACIACADQArApg0BxQgzByhzB3IgNAOQhsBthpA0QhAAhgpAAQgeAAgSgRg");
	this.shape_61.setTransform(-377.9142,78.4621);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFE0").s().p("Ai5EdIgEgFIjooSQCFgYB1AFQCDASCTgnQBUgPBsABIBnA0IACACIADACQAnAsg7BtQg7Bsh7BuQh7BvhxAvQg8AYgnAAQgkAAgTgUg");
	this.shape_62.setTransform(-376.1365,78.4954);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFE0").s().p("AjYEmIgEgFIjIo2IADgDQACgNAPgVQBzgNCEAcQCgAYBWgJQBkgWBSAhICCBOIACACIACADQAkAuhDBnQhCBniCBlQiBBkh0AnQg2ARgkAAQgsAAgTgZg");
	this.shape_63.setTransform(-375.6678,76.9659);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFE0").s().p("Aj9EdIgDgGIiaouQBLgcCJATQBoALBagTQAhgIAdgEQBJgLAqALIAOAFIDTCVIACABIACADQAfAwhJBiQhJBhiIBaQiIBah1AeQguAMggAAQg1AAgUgeg");
	this.shape_64.setTransform(-374.4002,76.9629);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFE0").s().p("AkfEPIgDgGIhuovQBygcBCAqQDZAnCfgJQAogFAoALICaB/IABACIACADQAcAyhPBbQhQBciNBPQiMBQh4AUQgjAGgcAAQhBAAgUgjg");
	this.shape_65.setTransform(-373.5728,76.93);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFE0").s().p("Ak8ETIgCgGIhHpJQCQACBnAUQBnAXBlgEIBpAJIDXDOIACACIABADQAZA0hWBUQhWBViSBEQiQBFh4AMQgWACgTAAQhTAAgUgqg");
	this.shape_66.setTransform(-372.9034,74.83);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFE0").s().p("AlaEQIgCgGIgbpIQBcgIA9AQQBtAZBOgPICWAIID/EbIABADIACADQAUA0hbBNQhbBOiVA6QiUA5h4ADIgNAAQhsAAgTgyg");
	this.shape_67.setTransform(-372.169,73.0701);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFE0").s().p("AjnFPQh3gFgQg2IgCgGIAQpFIAEgBQAFgKASgNQA0AbBzgKQBkgLBLAeQAuAxAlgoIEIFTIABADIABADQAQA2hgBGQhfBGiYAuQiGAphsAAIgcgBg");
	this.shape_68.setTransform(-372.3357,70.3096);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFE0").s().p("AjxFHQh1gOgMg3IgBgGIA5o+IAEgBIAAAAQA7gSBHAdQBcAgBcgSQApgMBKAVID6F3IACADIAAADQAMA3hjA/QhlA+iaAjQhrAYhaAAQgmAAgjgEg");
	this.shape_69.setTransform(-373.8604,69.3569);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFE0").s().p("Aj6FBQhzgXgIg3IAAgGIBhoxQBHgRBGAYQBqAYBJgPQA3gPAdATID0GvIABADIABADQAIA3hoA3QhoA3ibAXQhMALhEAAQhDAAg6gLg");
	this.shape_70.setTransform(-375.3714,67.8896);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFE0").s().p("AkBE0QhwgfgEg3IAAgGICHoXQBUgWAwAWQBfAdBGgdQA5gNAfANIDiHhIABACIAAADQAEA3hqAvQhsAvibAMQgpADgmAAQhpAAhSgXg");
	this.shape_71.setTransform(-376.8803,66.6083);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFE0").s().p("Ai2C7QhMgbAAgnIAAgEIBtlKQBZA/C/g/ICAFLIAAABIAAACQAAAnhMAbQhMAbhrAAQhrAAhLgbg");
	this.shape_72.setTransform(4.325,159.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_47}]},119).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[]},1).to({state:[{t:this.shape_72}]},130).wait(1));

	// Layer_4
	this.instance_5 = new lib.Symbol57();
	this.instance_5.setTransform(3.1,131.55,0.32,0.32,0,0,0,0,0.1);

	this.instance_6 = new lib.conicalflask2();
	this.instance_6.setTransform(-425.3,-51.5,0.2621,0.2621);
	this.instance_6._off = true;

	this.instance_7 = new lib.Symbol58();
	this.instance_7.setTransform(-378.35,63.05,0.46,0.46);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).to({state:[{t:this.instance_5}]},49).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_7},{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[]},1).wait(155));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(50).to({regY:0.3,scaleX:0.3231,scaleY:0.3231,x:-4.05,y:125.9},0).wait(1).to({regX:-0.1,regY:0.1,scaleX:0.3262,scaleY:0.3262,x:-11.25,y:120.3},0).wait(1).to({regX:0,regY:0.3,scaleX:0.3293,scaleY:0.3293,x:-18.4,y:114.9},0).wait(1).to({regX:-0.1,regY:0.1,scaleX:0.3324,scaleY:0.3324,x:-25.75,y:109.5},0).wait(1).to({regY:0.3,scaleX:0.3355,scaleY:0.3355,x:-33.1,y:104.25},0).wait(1).to({regX:0,regY:0.1,scaleX:0.3386,scaleY:0.3386,x:-40.5,y:99.05},0).wait(1).to({regX:-0.1,regY:0.3,scaleX:0.3417,scaleY:0.3417,x:-48.1,y:94.05},0).wait(1).to({regX:0,scaleX:0.3448,scaleY:0.3448,x:-55.65,y:89.1},0).wait(1).to({regX:-0.1,regY:0.1,scaleX:0.348,scaleY:0.348,x:-63.4,y:84.2},0).wait(1).to({regY:0.3,scaleX:0.3511,scaleY:0.3511,x:-71.15,y:79.55},0).wait(1).to({regX:0,regY:0.1,scaleX:0.3542,scaleY:0.3542,x:-78.95,y:74.9},0).wait(1).to({regX:-0.1,regY:0.3,scaleX:0.3573,scaleY:0.3573,x:-86.95,y:70.5},0).wait(1).to({regX:0,scaleX:0.3604,scaleY:0.3604,x:-94.9,y:66.15},0).wait(1).to({regX:-0.1,scaleX:0.3635,scaleY:0.3635,x:-103.05,y:61.95},0).wait(1).to({regY:0.2,scaleX:0.3666,scaleY:0.3666,x:-111.25,y:57.85},0).wait(1).to({regX:0,regY:0.1,scaleX:0.3697,scaleY:0.3697,x:-119.45,y:53.95},0).wait(1).to({regX:-0.1,regY:0.2,scaleX:0.3728,scaleY:0.3728,x:-127.85,y:50.25},0).wait(1).to({regX:0,regY:0.1,scaleX:0.376,scaleY:0.376,x:-136.2,y:46.65},0).wait(1).to({regX:-0.1,regY:0.2,scaleX:0.3791,scaleY:0.3791,x:-144.75,y:43.3},0).wait(1).to({scaleX:0.3822,scaleY:0.3822,x:-153.3,y:40.05},0).wait(1).to({regX:0,scaleX:0.3853,scaleY:0.3853,x:-161.9,y:36.95},0).wait(1).to({regX:-0.1,scaleX:0.3884,scaleY:0.3884,x:-170.7,y:34.1},0).wait(1).to({regX:0,regY:0.1,scaleX:0.3915,scaleY:0.3915,x:-179.4,y:31.4},0).wait(1).to({regX:-0.1,regY:0.2,scaleX:0.3946,scaleY:0.3946,x:-188.3,y:28.95},0).wait(1).to({regY:0.1,scaleX:0.3977,scaleY:0.3977,x:-197.2,y:26.6},0).wait(1).to({regX:0,regY:0.2,scaleX:0.4008,scaleY:0.4008,x:-206.15,y:24.6},0).wait(1).to({regX:-0.1,scaleX:0.404,scaleY:0.404,x:-215.2,y:22.7},0).wait(1).to({regX:0,scaleX:0.4071,scaleY:0.4071,x:-224.25,y:21.05},0).wait(1).to({regX:-0.1,scaleX:0.4102,scaleY:0.4102,x:-233.4,y:19.65},0).wait(1).to({regY:0.1,scaleX:0.4133,scaleY:0.4133,x:-242.55,y:18.4},0).wait(1).to({regX:0,regY:0.2,scaleX:0.4164,scaleY:0.4164,x:-251.7,y:17.5},0).wait(1).to({regX:-0.1,regY:0.1,scaleX:0.4195,scaleY:0.4195,x:-260.95,y:16.7},0).wait(1).to({regX:0,regY:0.2,scaleX:0.4226,scaleY:0.4226,x:-270.1,y:16.25},0).wait(1).to({regX:-0.1,scaleX:0.4257,scaleY:0.4257,x:-279.4,y:15.95},0).wait(1).to({scaleX:0.4288,scaleY:0.4288,x:-288.65,y:15.85},0).wait(1).to({regX:0,scaleX:0.4319,scaleY:0.4319,x:-297.85,y:16.1},0).wait(1).to({regX:-0.1,regY:0.1,scaleX:0.4351,scaleY:0.4351,x:-307.15,y:16.45},0).wait(1).to({regX:0,regY:0.2,scaleX:0.4382,scaleY:0.4382,x:-316.35,y:17.2},0).wait(1).to({scaleX:0.4413,scaleY:0.4413,x:-325.55,y:18.05},0).wait(1).to({regX:-0.1,scaleX:0.4444,scaleY:0.4444,x:-334.75,y:19.15},0).wait(1).to({regX:0,scaleX:0.4475,scaleY:0.4475,x:-343.85,y:20.5},0).wait(1).to({regX:-0.1,scaleX:0.4506,scaleY:0.4506,x:-353.05,y:22.05},0).wait(1).to({regX:0,scaleX:0.4537,scaleY:0.4537,x:-362.1,y:23.85},0).wait(1).to({scaleX:0.4568,scaleY:0.4568,x:-371.1,y:25.85},0).to({_off:true},1).wait(181));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(94).to({_off:false},0).wait(1).to({scaleX:0.264,scaleY:0.264,rotation:-4.1965,x:-434.15,y:-47.75},0).wait(1).to({scaleX:0.2658,scaleY:0.2658,rotation:-8.398,x:-442.8,y:-43.55},0).wait(1).to({scaleX:0.2676,scaleY:0.2676,rotation:-12.5972,x:-451.2,y:-38.9},0).wait(1).to({scaleX:0.2694,scaleY:0.2694,rotation:-16.7981,x:-459.3,y:-33.75},0).wait(1).to({scaleX:0.2713,scaleY:0.2713,rotation:-20.9982,x:-467.05,y:-28.25},0).wait(1).to({scaleX:0.2731,scaleY:0.2731,rotation:-25.1991,x:-474.5,y:-22.3},0).wait(1).to({scaleX:0.2749,scaleY:0.2749,rotation:-29.3966,x:-481.65,y:-15.9},0).wait(1).to({scaleX:0.2767,scaleY:0.2767,rotation:-33.5989,x:-488.3,y:-9.1},0).wait(1).to({scaleX:0.2785,scaleY:0.2785,rotation:-37.799,x:-494.65,y:-2.05},0).wait(1).to({scaleX:0.2804,scaleY:0.2804,rotation:-41.9979,x:-500.4,y:5.2},0).wait(1).to({scaleX:0.2822,scaleY:0.2822,rotation:-46.2006,x:-505.7,y:12.9},0).wait(1).to({scaleX:0.284,scaleY:0.284,rotation:-50.4017,x:-510.6,y:20.75},0).wait(1).to({scaleX:0.2858,scaleY:0.2858,rotation:-54.5996,x:-514.9,y:28.8},0).wait(1).to({scaleX:0.2877,scaleY:0.2877,rotation:-58.7981,x:-518.7,y:37.05},0).wait(1).to({scaleX:0.2895,scaleY:0.2895,rotation:-63.0027,x:-521.95,y:45.4},0).wait(1).to({scaleX:0.2913,scaleY:0.2913,rotation:-67.201,x:-524.7,y:53.85},0).wait(1).to({scaleX:0.2931,scaleY:0.2931,rotation:-71.4019,x:-526.8,y:62.4},0).wait(1).to({scaleX:0.295,scaleY:0.295,rotation:-75.6015,x:-528.4,y:70.85},0).wait(1).to({scaleX:0.2968,scaleY:0.2968,rotation:-79.8011,x:-529.35,y:79.3},0).wait(1).to({scaleX:0.2986,scaleY:0.2986,rotation:-84.0019,x:-529.8,y:87.65},0).wait(1).to({scaleX:0.3004,scaleY:0.3004,rotation:-88.2014,x:-529.65,y:95.95},0).wait(1).to({scaleX:0.3023,scaleY:0.3023,rotation:-92.3957,x:-529.05,y:104},0).wait(1).to({scaleX:0.3041,scaleY:0.3041,rotation:-96.5958,x:-527.85,y:111.9},0).wait(1).to({scaleX:0.3059,scaleY:0.3059,rotation:-100.7987,x:-526.15,y:119.55},0).wait(1).to({scaleX:0.3077,scaleY:0.3077,rotation:-104.9982,x:-523.8,y:126.9},0).to({_off:true},1).wait(155));

	// Layer_8
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFE0").s().p("AkBFBQhwgfgEg3IAAgGICLooIAEgBQAIgJAYgJIFSAVIDpHvIABADIAAADQAEA3hqAvQhsAvibALQgpADgmAAQhpAAhSgWg");
	this.shape_73.setTransform(-376.8803,65.3806);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFE0").s().p("Aj6FIQhzgXgIg3IAAgGIBio0IAEgBQAGgIASgJIFzAhID4G4IABACIABADQAIA3hoA3QhoA3ibAXQhMALhEAAQhDAAg6gLg");
	this.shape_74.setTransform(-375.3714,67.15);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFE0").s().p("AjxFQQh1gOgMg3IgBgGIA5o+IAEgBQAHgMAZgNIGDAsIEEGGIACADIAAADQAMA3hjA/QhlA+iaAjQhrAYhaAAQgmAAgjgEg");
	this.shape_75.setTransform(-373.8604,68.477);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFE0").s().p("AjnFUQh3gFgQg2IgCgGIAQpFIAEgBQAHgOAfgTIGNAnIEVFjIABADIABADQAQA2hgBGQhfBGiYAuQiGAphsAAIgcgBg");
	this.shape_76.setTransform(-372.3357,69.8221);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFE0").s().p("AlaEdIgCgGIgbpIIAEgBQAEgMAWgQIHGAxIEFEhIABACIACADQAUA1hbBOQhbBOiVA5QiUA5h4ADIgNAAQhsAAgTgyg");
	this.shape_77.setTransform(-372.169,71.733);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFE0").s().p("Ak8EbIgCgGIhHpJIADgBQADgHAHgIIIXA7IDfDVIACACIABADQAZAzhWBVQhWBViSBEQiQBFh4AMQgWACgTAAQhTAAgUgqg");
	this.shape_78.setTransform(-372.9034,74.005);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFE0").s().p("AkdEeIgDgGIhypGIAEgCQACgHAGgJIJkBNICqCMIABADIACADQAcAyhPBaQhQBciNBQQiMBPh4AVQgjAGgcAAQhBAAgUgjg");
	this.shape_79.setTransform(-373.7853,75.4981);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFE0").s().p("Aj7EaIgDgFIiepAIAEgCIADgKIJMAAIDZCaIACACIACADQAfAwhJBiQhJBgiIBbQiIBah1AeQguALggAAQg1AAgUgeg");
	this.shape_80.setTransform(-374.6252,77.2365);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFE0").s().p("AjYEpIgEgFIjIo2IADgDQACgQAWgcIKBAiICdBfIACACIACADQAkAuhDBnQhCBniCBlQiBBkh0AnQg2ARgkAAQgsAAgTgZg");
	this.shape_81.setTransform(-375.6678,76.6771);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFE0").s().p("Ai0EiIgEgFIjyooILGgqIB7A+IACACIADACQAnAsg7BtQg7Bsh7BuQh7BvhxAvQg8AYgnAAQgkAAgTgUg");
	this.shape_82.setTransform(-376.624,77.9954);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFE0").s().p("AiNEnIgFgFIkdoaIADgDQAAgLAIgTIMGgeIA2AXIADACIACADQArApg0BxQgzByhzB3QhzB4hvA3QhAAhgpAAQgeAAgSgRg");
	this.shape_83.setTransform(-377.9142,77.7996);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFE0").s().p("Ag6FJIgEgFIjOlHIhBhmIgagpIh+jEIAuAMIgDgGIOgBHIgEAYIgDACQABAMgCAPIgBAKIgCAMQgGAYgKAeQgJAXgKAXQgtBghWBoQhqCBhsBAQhEAogrAAQgZAAgRgOg");
	this.shape_84.setTransform(-383.7625,74.1552);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFE0").s().p("AAiFxIgFgEIliniIgTAAIi8joIAZAGIgVgLIBKgQIEPgJILFBxQASAqgZBYIgIAZIgGARQglBmhRByQhiCJhnBIQhGAxgtAAQgVAAgQgLg");
	this.shape_85.setTransform(-390.5436,69.6687);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFE0").s().p("AD0GkIgGgDImRnXIgKAAIi3jFIlZixIDCAJIJGBZIJzCTQgCAbgGAhQgHAigMAjQgOAsgWAtQgZA2giA5QhYCRhiBQQhHA6gvAAQgSAAgOgJg");
	this.shape_86.setTransform(-409.2,63.6434);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFE0").s().p("AEzGgIgGgEIm3m7IirifImci9IASgqIECAMISPC/QAAAYgEAfQgEAbgGAdQgGAbgJAcQgYBPgtBYQhOCYhcBYQhHBDgwAAQgPAAgNgGg");
	this.shape_87.setTransform(-413.1998,62.8885);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFE0").s().p("AFcGFIgGgDInOmkIiziVImminIARgrIA/gBIDEAZISPDUIgBADQgFAbgHAdQgUBRgoBaQhGCchYBcQhGBKgxAAQgNAAgLgGg");
	this.shape_88.setTransform(-415.775,64.6762);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFE0").s().p("AGWFbIgGgCIqbnyIg3gPImYiMIAPgqIWmBiQgCAlgGAoQgNBSgfBdQg3CjhQBmQhDBWg0AAQgKAAgJgEg");
	this.shape_89.setTransform(-418.9125,66.1133);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFE0").s().p("AHQE0IgGgCIoYlXIACgEQgEgHgDgMIgEATIiqhlInZh6IAKgtQFTAIFFAiIAWACQGIApF1BOQgHAogLAsIgBACQgrCnhIBtQhABeg2AAQgIAAgHgCg");
	this.shape_90.setTransform(-422.9875,67.6598);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFE0").s().p("AH0EiIgHgCIoIkbIAAACIkpiNImTgrIAPhuQFKgKFCAeIBXAJQFjAoFaBYIgGAgQgfCrhBByQg7Bog4AAIgLgBg");
	this.shape_91.setTransform(-424.975,66.9311);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFE0").s().p("AIaD/IgHgCIoej1IAAABIkPh3InEgXIAJh5QFIgDFJAPIB1AGQFXASFXAnIgDAcQgSCug5B3Qg2Bxg7AAIgGAAg");
	this.shape_92.setTransform(-427.4875,67.4619);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFE0").s().p("AI3DtIgHgBIpYjcIgBADIjThKIAAgJIneAAIAAhiQCEgSB1gfQB2gxB8AvQBTAdBNgNQAcgEAbgLQCfgxDdA8QC2AiDBALQgJCegsBxQgwB6g9AAIgCAAg");
	this.shape_93.setTransform(-429.2875,66.0367);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFE0").s().p("AJSEFIlVhhIAAABIobiRIm6AcIgHg9IAFAAQCLgXB7hCQCahSC8AfQAXAGAXADQCVAVCXhSQBuhXCUAxQB7AHCBgHQADAiACAkQAHCxgnCAQgnB/g/ADIgHgBg");
	this.shape_94.setTransform(-431.9652,60.0464);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFE0").s().p("AJqC/Ikrg+IABADIpyhwImgA+IgOhqQB7g8CMAXQCwA7CThoQAhgNAigKQCjgyDCANQDwARDcgpQAJCJgZBpQgeCDg/AIIgDAAIgEAAg");
	this.shape_95.setTransform(-434.0481,63.4125);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFE0").s().p("AHPDCIgZgDIiAgRIgSgDIhJgJIhYgLIgWgCIhCgKIAAACIkxgmInKBmIgQhMQCQg1CDgoQCqhQDKgJQAugBAtABQDTARBdhLQDSg+DMgsQAdCkgUB8QgUCFg/AMIgHABg");
	this.shape_96.setTransform(-436.0989,56.85);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFE0").s().p("ArgCHQCBhDBqAKQEKAOCEiYIABgBQC7ifCeAmQEWAKC2hcQAqClgLCAQgLCIg+AQIgHACIk4gSIABACIphgkImyCGg");
	this.shape_97.setTransform(-437.7957,56.1625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_73}]},95).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[]},1).wait(155));

	// Layer_1
	this.instance_8 = new lib.Symbol56();
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({_off:false},0).to({scaleX:2.35,scaleY:2.35,guide:{path:[0,0.1,-413.2,-66.8,-536.3,229]}},48).wait(135).to({_off:true},1).wait(90));

	// Layer_9
	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFE0").s().p("AjKWeIAAjMQAUgOAmAOQAlhSgnieIAHgXIgCgSIAEgHQBiighNigQhAkvBxiZQhejOCOjtQhCjsBxjVQhQjDB5jCIgBgJQgQipCXipQgvCFACCGQABAhADAiQgCAdgIAcIgOAhQhLC9AtB5IAAAEIgBAKIgCAQIgDAOIgCAHQhzCNA5DBIAAABIALAhIAIATIAAAAIgMAOIAAAgIgGAkQhcDHA8CgIgKAQIAAAsQiUD7B3CsQA+DhhlBzQAaDHgPA5QAYgaA5AaQAWAFAYADIAADEQhTAVhEAAQhFAAg1gVg");
	this.shape_98.setTransform(-512.7375,182.28);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFE0").s().p("AjKWeIAAksQAzATAZgTQAAg+gUhSIAHgXIgCgSIAEgHQBiighNigQhAkvBxiZQhejOCOjtQhCjsBxjVQhQjDB5jCIgBgJQgQipCXipQgvCFACCGQABAhADAiQgCAdgIAcIgOAhQhLC9AtB5IAAAEIgBAKIgCAQIgDAOIgCAHQhzCNA5DBIAAABIALAhIAIATIAAAAIgMAOIAAAgIgGAkQhcDHA8CgIgKAQIAAAsQiUD7B3CsQA+DhhlBzQANBfAYA/IABACIAfAAQAfARAmgRIAAEsQhTAVhEAAQhFAAg1gVg");
	this.shape_99.setTransform(-512.7375,182.28);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFE0").s().p("AjKWeIAAl1QAcAfAcgfIANgGQgFgegIgiIAAgBIAHgXIgCgSIAEgHQBiighNigQhAkvBxiZQhejOCOjtQhCjsBxjVQhQjDB5jCIgBgJQgQipCXipQgvCFACCGQABAhADAiQgCAdgIAcIgOAhQhLC9AtB5IAAAEIgBAKIgCAQIgDAOIgCAHQhzCNA5DBIAAABIALAhIAIATIAAAAIgMAOIAAAgIgGAkQhcDHA8CgIgKAQIAAAsQiUD7B3CsQA+DhhlBzIAIA7QAXgBAEAPIAAAOQABArBmgrIAAF1QhTAVhEAAQhFAAg1gVg");
	this.shape_100.setTransform(-512.7375,182.28);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFE0").s().p("Ai7V0IAAhmIAAhMIgBjDIAAgtIAAgDIAAgIIAAgPIAAgEIAAhHQAhAhAighIAAAbIAPgbQBMiShGiTQhBkvByiZQhejOCNjtQhCjsBxjVQhQjCB6jDIgBgJQgMh/BSh/IAjAUQgRBRACBSQAAAhAEAiQgDAdgIAcIgOAiQhLC9AuB5IgBADIgBAKIgCAQIgDAOIgBAIQh0CMA5DCIAAAAIAMAhIAHATIAAABIgMANIAAAgIgFAkQhdDHA9CgIgLAQIAAAsQiTD8B2CrQAhB6gOBZIgTBGQACA2Bhg2IAAIHQhTAVhEAAQhEAAg2gVgAgzOoIAAABIADAaIABAEIACASIAAgWIAQAAIABgaIgRAAIAAgIIgGAHg");
	this.shape_101.setTransform(-514.2758,186.4675);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFE0").s().p("Ai2VcIAApOQALARAbgRQA+gWABAWIAAAYIAIgYQAfhvg1hwQhBkuBxiaQhdjNCMjtQhBjsBxjVQhQjDB6jDIgBgJQgIhTAhhgIAKgZIA7AsQgFAtAAAsQABAiAEAhQgDAdgIAdIgOAhQhLC9AuB5IgBADIgBALIgCAPIgDAPIgBAHQh0CNA5DBIAAAAIALAiIAIATIAAAAIgMANIAAAhIgGAjQhcDHA9CgIgLAQIAAAsQiTD8B2CrQAbBjgEBOIgBAIIgDAaIADAAQA2gYABAYIAWAAIAAJOQhTAUhEAAQhEAAg2gUg");
	this.shape_102.setTransform(-514.775,188.93);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFE0").s().p("Ai2U0IAApNQALAQAbgQQA+gXABAWIAAAYIAIgXQAfhwg1hvQhBkvByiZQhejOCMjtQhBjsBxjVQhQjDB6jCIgBgJQgEgrAHguIBYglQgCAbABAcQAAAhAEAiQgDAdgIAcIgOAhQhLC9AuB5IgBAEIgBAKIgCAQIgDAOIgBAHQh0CNA5DBIAAABIAMAhIAHATIAAAAIgMAOIAAAgIgFAkQhcDHA8CgIgLAQIAAAsQiTD7B2CsQAbBjgEBOIgBAHIgDAbIADAAQA2gZABAZIAWAAIAAJNQhTAVhEAAQhEAAg2gVg");
	this.shape_103.setTransform(-514.7875,192.8925);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#0000FF").ss(1,1,1).p("AgqAMIBVgX");
	this.shape_104.setTransform(-501.1375,59.1);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFE0").s().p("Ai2UzIAApOQALARAbgRQA+gWABAWIAAAYIAIgYQAfhvg1hwQhBkuByiZQhejOCMjtQhBjsBxjVQhQjDB6jDIgBgJQgFgvAJgzIBXgYQgCAZABAaQAAAiAEAhQgDAdgIAdIgOAhQhLC9AuB5IgBADIgBALIgCAPIgDAPIgBAHQh0CNA5DBIAAAAIAMAiIAHATIAAAAIgMANIAAAhIgFAkQhcDHA8CgIgLAPIAAAsQiTD8B2CrQAbBjgEBOIgBAIIgDAaIADAAQA2gYABAYIAWAAIAAJOQhTAUhEAAQhEAAg2gUg");
	this.shape_105.setTransform(-514.7875,193.0175);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFE0").s().p("Ai1TwIAAqLQBkAZAPgZIAAAkQADgSABgSQAGhRgmhQQhBkvBxiYQhdjPCMjtQhBjsBxjVQg5iMAuiMQAIgYALgXIABgEQAjgcBZgdQgDAWgGAVIgIASIgGAQQhLC9AtB5IAAADIgBAKIgCAQIgDAOIgCAIQhzCMA5DCIAAAAIALAhIAIATIAAABIgMANIAAAgIgGAkQhcDHA9ChIgLAQIAAArQiTD8B2CrQARA/AEA3IABADIAAAcIABAAQBGAqAGgqIAAKLQhUAVhDAAQhFAAg1gVg");
	this.shape_106.setTransform(-514.8625,199.6675);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFE0").s().p("AiIFQIAAqzQABAPBWgQIAYAAQBRAdAGgdIAdAAQApAXAFgXIAAK0QhUAVhDAAQhFAAg1gVg");
	this.shape_107.setTransform(-519.35,292.48);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_98}]},111).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_105},{t:this.shape_104}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[]},66).wait(90));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-662.9,-105.5,697.5,461.1);


// stage content:
(lib.chem = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,1];
	// timeline functions:
	this.frame_0 = function() {
		createjs.Touch.enable(stage);
		
		this.stop();
		this.nxt_btn.addEventListener('click', showNext);
		var root = this;
		var apparatus = [this.beaker_MC, this.conical_MC, this.measuring_MC, this.testtube_MC, this.burette_MC, 
		                 this.bunsen_MC, this.therm_MC, this.clock_MC, this.pipette_MC];
		var clickedIndices = [];
		var targetIndices = [0, 1, 2, 6, 7];
		var partial = this.partial;
		var incorr = this.incorrect;
		var resetBtns = [this.partial.retry_1, this.incorrect.retry_2];
		
		for (reset of resetBtns){
			reset.addEventListener('click',rst);
		}
		
		function rst(){
			root.partial.x = root.incorrect.x = 1163;
			clickedIndices = [];
			apparatus.forEach((item) => {
				item.gotoAndStop(0);
				item.clickedColor.shape.graphics._stroke.style = "#00000";
			})
		}
		
		apparatus.forEach((item, index) => {
		    item.addEventListener('click', function() {
				item.clickedColor.shape.graphics._stroke.style = "#0033CC";
		        if (!clickedIndices.includes(index)) {
		            clickedIndices.push(index);
		        }
		    });
		});
		
		function partiallyCorrect(){
			createjs.Tween.get(partial)
				.to({x: 800.7, y: 315.85}, 1000)
				.play();
		}
		
		function incorrect(){
			createjs.Tween.get(incorr)
				.to({x: 800.7, y: 315.85}, 1000)
				.play();
		}
		
		function showNext() {
		    // Helper function to check if array A contains all elements from array B
		    function containsAll(arr1, arr2) {
		        return arr2.every(item => arr1.includes(item));
		    }
		
		    // Helper function to check if there are any incorrect selections
		    function hasIncorrectSelections(clicked, target) {
		        return clicked.some(index => !target.includes(index));
		    }
		
		    if (clickedIndices.length === targetIndices.length && 
		        containsAll(clickedIndices, targetIndices)) {
				root.gotoAndStop(1);
		        clickedIndices.forEach(index => {
		            apparatus[index].gotoAndStop(1);
		        });
		    } else if (clickedIndices.every(index => targetIndices.includes(index))) {
				root.partial.partial_text.text = "You have not selected all the apparatus to be used for the experiment.";
		        partiallyCorrect();
		        clickedIndices.forEach(index => {
		            apparatus[index].gotoAndStop(1);
		        });
		    } else if (hasIncorrectSelections(clickedIndices, targetIndices) && 
		             clickedIndices.some(index => targetIndices.includes(index))) {
				root.partial.partial_text.text = "Some of the apparatus you selected are not appropriate for the experment.";
		        partiallyCorrect();
		        clickedIndices.forEach(index => {
		            if (targetIndices.includes(index)) {
		                apparatus[index].gotoAndStop(1);  // Correct selections
		            } else {
		                apparatus[index].gotoAndStop(2);  // Incorrect selections
		            }
		        });
		    } else {
		        incorrect();
		        clickedIndices.forEach(index => {
		            apparatus[index].gotoAndStop(2);
		        });
		    }
		    clickedIndices = [];
		}
	}
	this.frame_1 = function() {
		createjs.Touch.enable(stage);
		
		if (!localStorage.getItem("userTemp")) {
		    localStorage.setItem("userTemp", "[]");
		    localStorage.setItem("userTime", "[]");
		    localStorage.setItem("userRate", "[]");
		}
		
		this.stop();
		var draggables = [this.paper, this.beaker, this.therm, this.stopClock];
		
		const timerArray = [110.0, 90.0, 70.0, 48.0, 32.0, 24.0];
		const temperature = [25.0, 35.0, 45.0, 55.0, 65.0, 75.0];
		
		var currentCycleIndex = 0; // Start at index 0
		var isAni1Playing = true; // Track animation 1 state
		var experimentCompleted = false; // Indicates if the experiment is completed
		var cycleCompleted = false; // Ensures animation completion logic runs once
		var tempReached = false; // Flag for temperature completion
		var timeReached = false; // Flag for timer completion
		var currentTemp = 22.0; // Default temperature
		var timerInterval; // Store timer interval for clearing
		const increment = 0.5; // Temperature increment value
		const updateInterval = 100; // Interval for temperature updates (ms)
		
		//=============================================================
		var currentTempIndex = 0;
		var ani1Count = 0;
		var ani2Count = 0;
		
		var tempInterval;
		
		var animationClickables = [this.measuringCylinder_1];
		var animations = [this.measuringAni_1, this.measuringAni_2];
		this.measuringAni_2.visible = 0;
		
		var root = this;
		var currentDropIndex = 0;
		var measuringCount = 0;
		
		// Track which objects have been placed
		var placedObjects = new Set();
		var usedTemperatures = new Set();
		
		const targetProperties = {
		    paper: {
		        x: 321.7,
		        y: 431.6,
		        scaleX: 0.67,
		        scaleY: 0.67,
		        skewX: 20,
		        skewY: 0
		    },
		    beaker: {
		        x: 322.2,
		        y: 344.2,
		        scaleX: 1,
		        scaleY: 1
		    },
		    therm: {
		        x: 292.8,
		        y: 288.95,
		        scaleX: 2.83,
		        scaleY: 2.83
		    },
		    stopClock: {
		        x: 91.8,
		        y: 524.3,
		        scaleX: 2.33,
		        scaleY: 2.33
		    }
		};
		
		const objectOrder = {
		    paper: 0,
		    beaker: 1,
		    therm: 2,
		    stopClock: 3
		};
		
		animations.forEach(item => {
		    item.visible = 0;
		});
		
		animationClickables.forEach(item => {
		    item.visible = 0;
		});
		
		// Initialize drag functionality for each object
		draggables.forEach(item => {
		    // Make item draggable
		    item.addEventListener("mousedown", startDrag);
		    item.addEventListener("pressmove", drag);
		    item.addEventListener("pressup", endDrag);
		    
		    // Store original properties
		    item.originalX = item.x;
		    item.originalY = item.y;
		    item.originalScaleX = item.scaleX;
		    item.originalScaleY = item.scaleY;
		    item.originalSkewX = item.skewX || 0;
		    item.originalSkewY = item.skewY || 0;
		});
		
		function startDrag(e) {
		    var obj = e.currentTarget;
		    
		    // Prevent dragging if object has been placed
		    if (placedObjects.has(obj.name.toLowerCase())) {
		        return;
		    }
		    
		    obj.offsetX = e.stageX - obj.x;
		    obj.offsetY = e.stageY - obj.y;
		    obj.parent.setChildIndex(obj, obj.parent.numChildren - 1);
		}
		
		function drag(e) {
		    var obj = e.currentTarget;
		    
		    // Prevent dragging if object has been placed
		    if (placedObjects.has(obj.name.toLowerCase())) {
		        return;
		    }
		    
		    obj.x = e.stageX - obj.offsetX;
		    obj.y = e.stageY - obj.offsetY;
		}
		
		function isInsideTable(obj, table) {
		    const tableBounds = {
		        left: root.table.x - (root.table.nominalBounds.width / 2),
		        right: root.table.x + (root.table.nominalBounds.width / 2),
		        top: root.table.y - (root.table.nominalBounds.height / 2),
		        bottom: root.table.y + (root.table.nominalBounds.height / 2)
		    };
		    
		    return (obj.x >= tableBounds.left &&
		            obj.x <= tableBounds.right &&
		            obj.y >= tableBounds.top &&
		            obj.y <= tableBounds.bottom);
		}
		
		function isInsideBeaker(obj) {
		    // Get beaker bounds
		    const beakerBounds = {
		        left: root.beaker.x - (root.beaker.nominalBounds.width * root.beaker.scaleX / 2),
		        right: root.beaker.x + (root.beaker.nominalBounds.width * root.beaker.scaleX / 2),
		        top: root.beaker.y - (root.beaker.nominalBounds.height * root.beaker.scaleY / 2),
		        bottom: root.beaker.y + (root.beaker.nominalBounds.height * root.beaker.scaleY / 2)
		    };
		    
		    return (obj.x >= beakerBounds.left &&
		            obj.x <= beakerBounds.right &&
		            obj.y >= beakerBounds.top &&
		            obj.y <= beakerBounds.bottom);
		}
		
		function reset(){
			root.resultsTable.visible = 0;
			root.therm.thermReading.text = '22.0';
			root.repeatExperiment.visible = 0;
		}
		reset();
		
		function checkDropTarget(obj, objName) {
		    // Thermometer needs beaker to be placed first and must be dropped in beaker
		    if (objName === 'therm') {
		        if (!placedObjects.has('beaker')) {
		            return false;
		        }
		        return isInsideBeaker(obj);
		    }
		    // All other objects use table as drop target
		    return isInsideTable(obj, root.table);
		}
		
		function endDrag(event) {
		    var obj = event.currentTarget;
		    var objName = obj.name.toLowerCase();
		    
		    // Prevent dragging if object has been placed
		    if (placedObjects.has(objName)) {
		        return;
		    }
		    
		    // Convert stopClock to match the property name if needed
		    if (objName === "stopclock") {
		        objName = "stopClock";
		    }
		    
		    if (targetProperties[objName]) {
		        // Check if it's this object's turn to be placed
		        if (objectOrder[objName] !== currentDropIndex) {
		            returnToOriginal(obj);
		            return;
		        }
		        
		        // Check if object is dropped in valid target
		        if (checkDropTarget(obj, objName)) {
		            // Apply target properties immediately when dropped
		            createjs.Tween.get(obj)
		                .to({
		                    x: targetProperties[objName].x,
		                    y: targetProperties[objName].y,
		                    scaleX: targetProperties[objName].scaleX,
		                    scaleY: targetProperties[objName].scaleY,
		                    skewX: targetProperties[objName].skewX || 0,
		                    skewY: targetProperties[objName].skewY || 0
		                }, 300, createjs.Ease.backOut);
		                
		            currentDropIndex++; // Increment to allow next object to be placed
		            
		            // Add object to placed set to prevent further dragging
		            placedObjects.add(objName);
		            
		            // Remove event listeners for placed object
		            obj.removeEventListener("mousedown", startDrag);
		            obj.removeEventListener("pressmove", drag);
		            obj.removeEventListener("pressup", endDrag);
		
		            // Manage layer ordering
		            const container = obj.parent;
		            
		            // First, move all existing placed objects to their proper layers
		            if (placedObjects.has('paper')) {
		                container.setChildIndex(root.paper, container.numChildren - 4);
		            }
		            if (placedObjects.has('therm')) {
		                container.setChildIndex(root.therm, container.numChildren - 3);
		            }
		            if (placedObjects.has('beaker')) {
		                container.setChildIndex(root.beaker, container.numChildren - 2);
		            }
		            if (placedObjects.has('stopClock')) {
		                container.setChildIndex(root.stopClock, container.numChildren - 1);
		            }
		
		            // Then, place the current object at its proper layer
		            if (objName === 'paper') {
		                container.setChildIndex(obj, container.numChildren - 4);
		            } else if (objName === 'therm') {
		                container.setChildIndex(obj, container.numChildren - 3);
		            } else if (objName === 'beaker') {
		                container.setChildIndex(obj, container.numChildren - 2);
		            } else if (objName === 'stopClock') {
		                container.setChildIndex(obj, container.numChildren - 1);
		            }
		
		            // Check if this was the stopClock being dropped
		            if (objName === "stopClock") {
		                root.instructions.gotoAndStop(1);
		                animationClickables.forEach(item => {
		                    item.visible = 1;
		                });
						animations.forEach(item => {
							item.visible = 1;
						});
		            }
		        } else {
		            returnToOriginal(obj);
		        }
		    }
		}
		
		function returnToOriginal(obj) {
		    createjs.Tween.get(obj)
		        .to({
		            x: obj.originalX,
		            y: obj.originalY,
		            scaleX: obj.originalScaleX,
		            scaleY: obj.originalScaleY,
		            skewX: obj.originalSkewX,
		            skewY: obj.originalSkewY
		        }, 300, createjs.Ease.backOut);
		}
		
		//====================================================================================
		
		// Updated animation clickable event listener
		animationClickables.forEach((item, index) => {
		    item.addEventListener("click", function () {
		        if (experimentCompleted) return;
		
		        // Dynamically fetch current cycle's target values
		        const targetTemp = temperature[currentCycleIndex];
		        const targetTime = timerArray[currentCycleIndex];
		
		        if (isAni1Playing) {
		            // Existing animation 1 logic with dynamic target
		            root.measuringAni_1.visible = 1;
		            root.measuringAni_1.gotoAndPlay(2);
		
		            function ani1TickHandler(event) {
		                if (root.measuringAni_1.currentFrame === 225) {
		                    startTempCount(targetTemp);
		                }
		
		                if (root.measuringAni_1.currentFrame === 274) {
		                    createjs.Ticker.off("tick", ani1TickHandler);
		                    root.resultsTable.visible = 1;
							alignPositions();
		                    isAni1Playing = false;
		                }else if(root.measuringAni_1.currentFrame != 274){
							root.resultsTable.visible = 0;
							removeFromStage();
						}
		            }
		
		            createjs.Ticker.on("tick", ani1TickHandler);
		        } else {
		            // Existing animation 2 logic with dynamic target
		            root.measuringAni_2.visible = 1;
		            root.measuringAni_2.gotoAndPlay(2);
		
		            root.stopClock.counter.text = "00:00";
		
		            function ani2TickHandler(event) {
		                if (root.measuringAni_2.currentFrame === 198) {
							const targetTime = timerArray[currentCycleIndex]; // Use current cycle index
							startTimer(targetTime);
						}
		
		                if (root.measuringAni_2.currentFrame === 254 && tempReached && timeReached) {
		                    cycleCompleted = true;
		                    createjs.Ticker.off("tick", ani2TickHandler);
		
		                    setTimeout(() => {
		                        tempReached = false;
		                        timeReached = false;
		                        cycleCompleted = false;
		                    }, 0);
		                }
					
						if (root.measuringAni_2.currentFrame === 254) {
							root.repeatExperiment.visible = 1;
						}else {
							root.repeatExperiment.visible = 0;
						}
		            }
		
		            createjs.Ticker.on("tick", ani2TickHandler);
		        }
		    });
		});
		
		function startTempCount(targetTemp) {
		    // Clear any existing interval first
		    if (tempInterval) {
		        clearInterval(tempInterval);
		    }
		    
		    // Always reset to starting temperature
		    currentTemp = 22.0;
		    root.therm.thermReading.text = currentTemp.toFixed(1);
		
		    tempInterval = setInterval(() => {
		        if (currentTemp >= targetTemp) {
		            currentTemp = targetTemp;
		            root.therm.thermReading.text = currentTemp.toFixed(1);
		            clearInterval(tempInterval);
		            tempReached = true;
		        } else {
		            currentTemp = Math.min(currentTemp + increment, targetTemp);
		            root.therm.thermReading.text = currentTemp.toFixed(1);
		        }
		    }, updateInterval);
		}
		
		function startTimer(targetTime) {
		    var seconds = 0;
		    var milliseconds = 0;
		
		    // Reset cross alpha at start of timer
		    root.paper.cross.alpha = 1;
		    root.stopClock.counter.text = "00:00";
		
		    // Clear any existing timer
		    if (timerInterval) {
		        clearInterval(timerInterval);
		    }
		
		    timerInterval = setInterval(() => {
		        milliseconds += 1;
		        if (milliseconds >= 60) {
		            seconds += 1;
		            milliseconds = 0;
		        }
		
		        const currentTime = parseFloat(`${seconds}.${(milliseconds * 1000) / 60}`);
		
		        root.stopClock.counter.text =
		            `${String(seconds).padStart(2, '0')}:${String(milliseconds).padStart(2, '0')}`;
		
		        // Only reduce alpha if timer is running
		        reduceXAlpha(targetTime);
		
		        if (currentTime >= targetTime) {
		            clearInterval(timerInterval);
		            timerInterval = null;
		            timeReached = true;
		            root.stopClock.counter.text =
		                `${String(Math.floor(targetTime)).padStart(2, '0')}:${String((targetTime % 1 * 60).toFixed(0)).padStart(2, '0')}`;
		        }
		    }, 16);
		}
		
		root.repeatExperiment.addEventListener("click", function () {
		    const currentTemperature = parseFloat(root.therm.thermReading.text);
		    const targetTemp = temperature[currentCycleIndex];
		    
		    const currentTimer = root.stopClock.counter.text;
		    const targetTime = timerArray[currentCycleIndex];
		    
		    const temperatureReached = Math.abs(currentTemperature - targetTemp) < 0.1;
		    const hasReachedTargetTime = parseFloat(currentTimer.replace(':', '.')) >= targetTime;
		    
		    if (temperatureReached && hasReachedTargetTime) {
		        // Clear any existing timer interval
		        if (timerInterval) {
		            clearInterval(timerInterval);
		            timerInterval = null;
		        }
		        
		        // Check if we've completed all cycles
		        if (currentCycleIndex === temperature.length - 1) {
		            // Reset to beginning
		            currentCycleIndex = 0;
					currentTemp = 22.0;
					resetValues();
		        } else {
		            // Move to next cycle
		            //currentCycleIndex++;
					currentCycleIndex = (currentCycleIndex + 1) % temperature.length;
		        }
		        
		        root.measuringAni_1.gotoAndStop(0);
		        root.measuringAni_2.gotoAndStop(0);
		        
		        // Reset displays
		        root.therm.thermReading.text = '22.0';
		        root.stopClock.counter.text = '00:00';
		        
		        // Immediately reset cross alpha
		        root.paper.cross.alpha = 1;
		        
		        isAni1Playing = true;
		        tempReached = false;
		        timeReached = false;
		        cycleCompleted = false;
		    } else {
		        console.log("Cannot repeat. Wait for the current cycle to complete.");
		    }
		});
		
		//===========================================================================================================
		
		var holders = [this.placeHolder_1, this.placeHolder_2, this.placeHolder_3, this.placeHolder_4]; 
		
		holders.forEach(item => {
		    item.visible = 0;
		});
		
		//========================================================================================================
		
		function reduceXAlpha(maxTime) {
		    // Only reduce alpha if timer is running
		    if (timerInterval) {
		        const currentTime = parseFloat(root.stopClock.counter.text.replace(':', '.'));
		        const alphaValue = 1 - (currentTime / maxTime);
		        root.paper.cross.alpha = Math.max(0, alphaValue);
		    }
		}
		
		//========================================================================================
		
		var temp_positions = [this.tp_1, this.tp_2, this.tp_3, this.tp_4, this.tp_5, this.tp_6];
		var time_positions = [this.ti_1, this.ti_2, this.ti_3, this.ti_4, this.ti_5, this.ti_6];
		var rate_positions = [this.rt_1, this.rt_2, this.rt_3, this.rt_4, this.rt_5, this.rt_6];
		
		var temp = [this.temp_1, this.temp_2, this.temp_3, this.temp_4, this.temp_5, this.temp_6];
		var time = [this.time_1, this.time_2, this.time_3, this.time_4, this.time_5, this.time_6];
		var rate = [this.rate_1, this.rate_2, this.rate_3, this.rate_4, this.rate_5, this.rate_6];
		
		var userTemp = [];
		var userTime = [];
		var userRate = [];
		
		function alignElements(elements, positions) {
		    elements.forEach((element, index) => {
		        const reference = positions[index];
		        if (element && reference) {
		            element.x = reference.x;
		            element.y = reference.y;
		        }
		    });
		}
		
		function alignPositions() {
			alignElements(temp, temp_positions);
			alignElements(time, time_positions);
			alignElements(rate, rate_positions);
		}
		
		var allowedChars = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '.'];
		
		function values() {
		    // Initialize arrays from localStorage or create empty arrays
		    window.userTemp = JSON.parse(localStorage.getItem("userTemp")) || [];
		    window.userTime = JSON.parse(localStorage.getItem("userTime")) || [];
		    window.userRate = JSON.parse(localStorage.getItem("userRate")) || [];
		
		    // Input group configuration
		    const inputGroups = {
		        temp: ["temp_1", "temp_2", "temp_3", "temp_4", "temp_5", "temp_6"],
		        time: ["time_1", "time_2", "time_3", "time_4", "time_5", "time_6"],
		        rate: ["rate_1", "rate_2", "rate_3", "rate_4", "rate_5", "rate_6"]
		    };
		
		    // Initialize input fields with stored values
		    Object.entries(inputGroups).forEach(([group, ids]) => {
		        ids.forEach((id, index) => {
		            const input = document.getElementById(id);
		            if (input) {
		                // Load stored value if it exists
		                input.value = window[`user${group.charAt(0).toUpperCase() + group.slice(1)}`][index] || '';
		                
		                // Add input listener
		                input.addEventListener("input", (e) => {
		                    // Clean input value
		                    const rawValue = e.currentTarget.value;
		                    const cleanedValue = rawValue.replace(/[^0-9.]/g, '');
		                    const numericValue = parseFloat(cleanedValue) || 0;
		
		                    // Update input display (preserve user's text input)
		                    e.currentTarget.value = cleanedValue;
		
		                    // Update corresponding array
		                    switch(group) {
		                        case 'temp':
		                            userTemp[index] = numericValue;
		                            break;
		                        case 'time':
		                            userTime[index] = numericValue;
		                            break;
		                        case 'rate':
		                            userRate[index] = numericValue;
		                            break;
		                    }
		
		                    // Save to localStorage
		                    localStorage.setItem("userTemp", JSON.stringify(userTemp));
		                    localStorage.setItem("userTime", JSON.stringify(userTime));
		                    localStorage.setItem("userRate", JSON.stringify(userRate));
		
		                    // Optional: Dispatch event for external scripts
		                    const event = new CustomEvent("experimentDataUpdated", {
		                        detail: {
		                            temp: userTemp,
		                            time: userTime,
		                            rate: userRate
		                        }
		                    });
		                    window.dispatchEvent(event);
		                });
		            }
		        });
		    });
		
		    // Validation regex pattern
		    const allowedChars = /[0-9.]/;
		
		    // Input validation function
		    function validateInput(e) {
		        const input = e.currentTarget;
		        const newValue = input.value.split('')
		            .filter(char => allowedChars.test(char))
		            .join('');
		
		        // Prevent multiple decimal points
		        const decimalCount = newValue.split('.').length - 1;
		        if (decimalCount > 1) {
		            input.value = newValue.replace(/\.+$/, '');
		            return;
		        }
		
		        input.value = newValue;
		    }
		
		    // Add validation to all inputs
		    Object.values(inputGroups).flat().forEach(id => {
		        const input = document.getElementById(id);
		        if (input) {
		            input.addEventListener("input", validateInput);
		        }
		    });
		}
		setTimeout(values, 100);
		
		function removeFromStage() {
			for(tp of temp){
				tp.x = 2000;
			}
		
			for(ti of time){
				ti.x = 2000;
			}
		
			for(rt of rate){
				rt.x = 2000;
			}
		}
		
		function resetValues() {
		    userTemp = [];
		    userTime = [];
		    userRate = [];
		    
		    // Update localStorage (still needed)
		    localStorage.setItem("userTemp", JSON.stringify(userTemp));
		    localStorage.setItem("userTime", JSON.stringify(userTime));
		    localStorage.setItem("userRate", JSON.stringify(userRate));
		    
		    // Reset input fields
		    const inputGroups = {
		        temp: ["temp_1", "temp_2", "temp_3", "temp_4", "temp_5", "temp_6"],
		        time: ["time_1", "time_2", "time_3", "time_4", "time_5", "time_6"],
		        rate: ["rate_1", "rate_2", "rate_3", "rate_4", "rate_5", "rate_6"]
		    };
		
		    Object.values(inputGroups).flat().forEach(id => {
		        const input = document.getElementById(id);
		        if (input) {
		            input.value = '';
		        }
		    });
		}
		resetValues();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.repeatExperiment = new lib.Symbol74();
	this.repeatExperiment.name = "repeatExperiment";
	this.repeatExperiment.setTransform(489.4,557);
	this.repeatExperiment._off = true;
	new cjs.ButtonHelper(this.repeatExperiment, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.repeatExperiment).wait(1).to({_off:false},0).wait(1));

	// ani_1
	this.measuringAni_1 = new lib.animation_2();
	this.measuringAni_1.name = "measuringAni_1";
	this.measuringAni_1.setTransform(658.95,110.6);
	this.measuringAni_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.measuringAni_1).wait(1).to({_off:false},0).wait(1));

	// ani_2
	this.measuringAni_2 = new lib.Symbol54();
	this.measuringAni_2.name = "measuringAni_2";
	this.measuringAni_2.setTransform(662.3,366.2);
	this.measuringAni_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.measuringAni_2).wait(1).to({_off:false},0).wait(1));

	// Layer_3
	this.placeHolder_4 = new lib.Symbol63();
	this.placeHolder_4.name = "placeHolder_4";
	this.placeHolder_4.setTransform(91.8,524.3,2.3299,2.3299);

	this.stopClock = new lib.Symbol63();
	this.stopClock.name = "stopClock";
	this.stopClock.setTransform(655.65,503.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.stopClock},{t:this.placeHolder_4}]},1).wait(1));

	// input_Locations
	this.rt_6 = new lib.Symbol73();
	this.rt_6.name = "rt_6";
	this.rt_6.setTransform(472.95,82.25);
	this.rt_6.visible = false;

	this.ti_6 = new lib.Symbol73();
	this.ti_6.name = "ti_6";
	this.ti_6.setTransform(472.95,55.3);
	this.ti_6.visible = false;

	this.tp_6 = new lib.Symbol73();
	this.tp_6.name = "tp_6";
	this.tp_6.setTransform(472.95,28.7);
	this.tp_6.visible = false;

	this.rt_5 = new lib.Symbol73();
	this.rt_5.name = "rt_5";
	this.rt_5.setTransform(414.5,82.25);
	this.rt_5.visible = false;

	this.ti_5 = new lib.Symbol73();
	this.ti_5.name = "ti_5";
	this.ti_5.setTransform(414.5,55.3);
	this.ti_5.visible = false;

	this.tp_5 = new lib.Symbol73();
	this.tp_5.name = "tp_5";
	this.tp_5.setTransform(414.5,28.7);
	this.tp_5.visible = false;

	this.rt_4 = new lib.Symbol73();
	this.rt_4.name = "rt_4";
	this.rt_4.setTransform(354.65,82.25);
	this.rt_4.visible = false;

	this.ti_4 = new lib.Symbol73();
	this.ti_4.name = "ti_4";
	this.ti_4.setTransform(354.65,55.3);
	this.ti_4.visible = false;

	this.tp_4 = new lib.Symbol73();
	this.tp_4.name = "tp_4";
	this.tp_4.setTransform(354.65,28.7);
	this.tp_4.visible = false;

	this.rt_3 = new lib.Symbol73();
	this.rt_3.name = "rt_3";
	this.rt_3.setTransform(295.5,82.25);
	this.rt_3.visible = false;

	this.ti_3 = new lib.Symbol73();
	this.ti_3.name = "ti_3";
	this.ti_3.setTransform(295.5,55.3);
	this.ti_3.visible = false;

	this.tp_3 = new lib.Symbol73();
	this.tp_3.name = "tp_3";
	this.tp_3.setTransform(295.5,28.7);
	this.tp_3.visible = false;

	this.rt_2 = new lib.Symbol73();
	this.rt_2.name = "rt_2";
	this.rt_2.setTransform(236.7,82.25);
	this.rt_2.visible = false;

	this.ti_2 = new lib.Symbol73();
	this.ti_2.name = "ti_2";
	this.ti_2.setTransform(236.7,55.3);
	this.ti_2.visible = false;

	this.tp_2 = new lib.Symbol73();
	this.tp_2.name = "tp_2";
	this.tp_2.setTransform(236.7,28.7);
	this.tp_2.visible = false;

	this.rt_1 = new lib.Symbol73();
	this.rt_1.name = "rt_1";
	this.rt_1.setTransform(175.8,82.25);
	this.rt_1.visible = false;

	this.ti_1 = new lib.Symbol73();
	this.ti_1.name = "ti_1";
	this.ti_1.setTransform(175.8,55.3);
	this.ti_1.visible = false;

	this.tp_1 = new lib.Symbol73();
	this.tp_1.name = "tp_1";
	this.tp_1.setTransform(175.8,28.7);
	this.tp_1.visible = false;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.tp_1},{t:this.ti_1},{t:this.rt_1},{t:this.tp_2},{t:this.ti_2},{t:this.rt_2},{t:this.tp_3},{t:this.ti_3},{t:this.rt_3},{t:this.tp_4},{t:this.ti_4},{t:this.rt_4},{t:this.tp_5},{t:this.ti_5},{t:this.rt_5},{t:this.tp_6},{t:this.ti_6},{t:this.rt_6}]},1).wait(1));

	// results_table
	this.resultsTable = new lib.Symbol72("synched",0);
	this.resultsTable.name = "resultsTable";
	this.resultsTable.setTransform(280.2,68.35);

	this.instance = new lib.an_CSS({'id': '', 'href':'assets/input.css'});

	this.instance.setTransform(-126.25,252,1,1,0,0,0,50,11);

	this.rate_6 = new lib.an_TextInput({'id': 'rate_6', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.rate_6.name = "rate_6";
	this.rate_6.setTransform(-94.75,507.95,0.5,1);

	this.time_6 = new lib.an_TextInput({'id': 'time_6', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.time_6.name = "time_6";
	this.time_6.setTransform(-94.75,480.75,0.5,1);

	this.temp_6 = new lib.an_TextInput({'id': 'temp_6', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.temp_6.name = "temp_6";
	this.temp_6.setTransform(-94.75,453.55,0.5,1);

	this.rate_5 = new lib.an_TextInput({'id': 'rate_5', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.rate_5.name = "rate_5";
	this.rate_5.setTransform(-153.75,507.95,0.5,1);

	this.time_5 = new lib.an_TextInput({'id': 'time_5', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.time_5.name = "time_5";
	this.time_5.setTransform(-153.75,480.75,0.5,1);

	this.temp_5 = new lib.an_TextInput({'id': 'temp_5', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.temp_5.name = "temp_5";
	this.temp_5.setTransform(-153.75,453.55,0.5,1);

	this.rate_4 = new lib.an_TextInput({'id': 'rate_4', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.rate_4.name = "rate_4";
	this.rate_4.setTransform(-211.75,507.95,0.5,1);

	this.time_4 = new lib.an_TextInput({'id': 'time_4', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.time_4.name = "time_4";
	this.time_4.setTransform(-211.75,480.75,0.5,1);

	this.temp_4 = new lib.an_TextInput({'id': 'temp_4', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.temp_4.name = "temp_4";
	this.temp_4.setTransform(-211.75,453.55,0.5,1);

	this.rate_3 = new lib.an_TextInput({'id': 'rate_3', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.rate_3.name = "rate_3";
	this.rate_3.setTransform(-271.25,507.95,0.5,1);

	this.time_3 = new lib.an_TextInput({'id': 'time_3', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.time_3.name = "time_3";
	this.time_3.setTransform(-271.25,480.75,0.5,1);

	this.temp_3 = new lib.an_TextInput({'id': 'temp_3', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.temp_3.name = "temp_3";
	this.temp_3.setTransform(-271.25,453.55,0.5,1);

	this.rate_2 = new lib.an_TextInput({'id': 'rate_2', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.rate_2.name = "rate_2";
	this.rate_2.setTransform(-330.25,507.95,0.5,1);

	this.time_2 = new lib.an_TextInput({'id': 'time_2', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.time_2.name = "time_2";
	this.time_2.setTransform(-330.25,480.75,0.5,1);

	this.temp_2 = new lib.an_TextInput({'id': 'temp_2', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.temp_2.name = "temp_2";
	this.temp_2.setTransform(-330.25,453.55,0.5,1);

	this.rate_1 = new lib.an_TextInput({'id': 'rate_1', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.rate_1.name = "rate_1";
	this.rate_1.setTransform(-388.75,507.95,0.5,1);

	this.time_1 = new lib.an_TextInput({'id': 'time_1', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.time_1.name = "time_1";
	this.time_1.setTransform(-388.75,480.75,0.5,1);

	this.temp_1 = new lib.an_TextInput({'id': 'temp_1', 'value':'', 'disabled':false, 'visible':true, 'class':'ui-textinput'});

	this.temp_1.name = "temp_1";
	this.temp_1.setTransform(-388.75,453.55,0.5,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.temp_1},{t:this.time_1},{t:this.rate_1},{t:this.temp_2},{t:this.time_2},{t:this.rate_2},{t:this.temp_3},{t:this.time_3},{t:this.rate_3},{t:this.temp_4},{t:this.time_4},{t:this.rate_4},{t:this.temp_5},{t:this.time_5},{t:this.rate_5},{t:this.temp_6},{t:this.time_6},{t:this.rate_6},{t:this.instance},{t:this.resultsTable}]},1).wait(1));

	// draggables_2
	this.measuringCylinder_1 = new lib.Symbol53();
	this.measuringCylinder_1.name = "measuringCylinder_1";
	this.measuringCylinder_1.setTransform(659,110.6,0.37,0.37,0,0,0,0.1,0);
	new cjs.ButtonHelper(this.measuringCylinder_1, 0, 1, 1);

	this.instance_1 = new lib.mc();
	this.instance_1.setTransform(-739.35,336.9,0.6,0.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.039)").s().p("Ak2W6IplAAMAAAgtzIJlAAITSAAMAAAAtzg");
	this.shape.setTransform(-646.925,483.425);

	this.shape_1 = new cjs.Shape();
	var sprImg_shape_1 = cjs.SpriteSheetUtils.extractFrame(ss["chem_atlas_2"],42);
	sprImg_shape_1.onload = function(){
		this.shape_1.graphics.bf(sprImg_shape_1, null, new cjs.Matrix2D(1,0,0,1,-123.5,-242.5)).s().p("EgTSAl5IAAvAITSAAMAAAgtyIzSAAIAAu/MAmlAAAMAAABLxg")
	}.bind(this);
	this.shape_1.setTransform(-554.5,483.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance_1},{t:this.measuringCylinder_1}]},1).wait(1));

	// draggables_1
	this.therm = new lib.Symbol61();
	this.therm.name = "therm";
	this.therm.setTransform(650.8,371.55);

	this.beaker = new lib.Symbol46();
	this.beaker.name = "beaker";
	this.beaker.setTransform(655.5,240.55,0.34,0.34,0,0,0,0.5,0.3);

	this.paper = new lib.Symbol43();
	this.paper.name = "paper";
	this.paper.setTransform(655.45,111,0.3185,0.2694,0,0,0,0.3,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.paper},{t:this.beaker},{t:this.therm}]},1).wait(1));

	// Layer_5
	this.bunsen_MC = new lib.Symbol25();
	this.bunsen_MC.name = "bunsen_MC";
	this.bunsen_MC.setTransform(535.7,309.95);

	this.pipette_MC = new lib.Symbol24();
	this.pipette_MC.name = "pipette_MC";
	this.pipette_MC.setTransform(326.7,310.5);

	this.clock_MC = new lib.Symbol23();
	this.clock_MC.name = "clock_MC";
	this.clock_MC.setTransform(326.7,506.05);

	this.therm_MC = new lib.Symbol22();
	this.therm_MC.name = "therm_MC";
	this.therm_MC.setTransform(118.8,506.05);

	this.burette_MC = new lib.Symbol14();
	this.burette_MC.name = "burette_MC";
	this.burette_MC.setTransform(535.7,505.5);

	this.testtube_MC = new lib.Symbol13();
	this.testtube_MC.name = "testtube_MC";
	this.testtube_MC.setTransform(118.8,304.6,1,1,0,0,0,0,0.1);

	this.measuring_MC = new lib.Symbol12();
	this.measuring_MC.name = "measuring_MC";
	this.measuring_MC.setTransform(525.1,116.1,1,1,0,0,0,0.1,0.1);

	this.conical_MC = new lib.Symbol11();
	this.conical_MC.name = "conical_MC";
	this.conical_MC.setTransform(326.7,119.65);

	this.beaker_MC = new lib.Symbol8_1();
	this.beaker_MC.name = "beaker_MC";
	this.beaker_MC.setTransform(118.8,119.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.beaker_MC},{t:this.conical_MC},{t:this.measuring_MC},{t:this.testtube_MC},{t:this.burette_MC},{t:this.therm_MC},{t:this.clock_MC},{t:this.pipette_MC},{t:this.bunsen_MC}]}).to({state:[]},1).wait(1));

	// Layer_4
	this.incorrect = new lib.Symbol8("synched",0);
	this.incorrect.name = "incorrect";
	this.incorrect.setTransform(1530.5,315.85);

	this.partial = new lib.Symbol6();
	this.partial.name = "partial";
	this.partial.setTransform(1163,315.85);

	this.placeHolder_1 = new lib.Symbol46();
	this.placeHolder_1.name = "placeHolder_1";
	this.placeHolder_1.setTransform(322.2,344.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.partial},{t:this.incorrect}]}).to({state:[{t:this.placeHolder_1}]},1).wait(1));

	// Layer_2
	this.nxt_btn = new lib.Symbol7();
	this.nxt_btn.name = "nxt_btn";
	this.nxt_btn.setTransform(878.1,561.3);
	new cjs.ButtonHelper(this.nxt_btn, 0, 1, 1);

	this.instance_2 = new lib.CachedBmp_1();
	this.instance_2.setTransform(662.65,128.85,0.5,0.5);

	this.placeHolder_2 = new lib.Symbol61();
	this.placeHolder_2.name = "placeHolder_2";
	this.placeHolder_2.setTransform(292.8,288.95,2.8298,2.8298);

	this.placeHolder_3 = new lib.Symbol43();
	this.placeHolder_3.name = "placeHolder_3";
	this.placeHolder_3.setTransform(321.8,431.85,0.67,0.6699,0,19.9996,0,0.3,0.4);

	this.table = new lib.Symbol42();
	this.table.name = "table";
	this.table.setTransform(291.95,452.25,1.12,0.99,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.nxt_btn}]}).to({state:[{t:this.table},{t:this.placeHolder_3},{t:this.placeHolder_2}]},1).wait(1));

	// instructions
	this.instance_3 = new lib.CachedBmp_3();
	this.instance_3.setTransform(685.25,67.2,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_2();
	this.instance_4.setTransform(12.35,19,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_9();
	this.instance_5.setTransform(1008.25,367.8,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_8();
	this.instance_6.setTransform(1008.25,289.85,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_7();
	this.instance_7.setTransform(1008.25,208.65,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_6();
	this.instance_8.setTransform(1008.25,110.9,0.5,0.5);

	this.instructions = new lib.Symbol48();
	this.instructions.name = "instructions";
	this.instructions.setTransform(855.6,215.65);

	this.instance_9 = new lib.CachedBmp_5();
	this.instance_9.setTransform(753.3,49.5,0.5,0.5);

	this.instance_10 = new lib.Symbol30copy2();
	this.instance_10.setTransform(607.85,462.55,0.91,0.77);

	this.instance_11 = new lib.Symbol30copy2();
	this.instance_11.setTransform(607.85,332.95,0.91,0.77);

	this.instance_12 = new lib.Symbol30copy2();
	this.instance_12.setTransform(607.85,203.4,0.91,0.77);

	this.instance_13 = new lib.Symbol30copy2();
	this.instance_13.setTransform(607.85,73.8,0.91,0.77);

	this.instance_14 = new lib.CachedBmp_4();
	this.instance_14.setTransform(593.45,58.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3}]}).to({state:[{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instructions},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5}]},1).wait(1));

	// Layer_7
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(51,153,153,0.078)").s().p("EARXAsPIAAhIMgisAAAIAABII1SAAQh7AAhYhUQhXhTAAh2MAAAhPjQAAh2BXhTQBYhUB7AAMBNPAAAQB7AABYBUQBXBTAAB2MAAABPjQAAB2hXBTQhYBUh7AAg");
	this.shape_2.setTransform(291.625,311.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#319FD0").s().p("EgNRArpQh2AAhUhTQhThUAAh2MAAAhOXQAAh2BThUQBUhTB2AAIajAAQB2AABUBTQBTBUAAB2MAAABOXQAAB2hTBUQhUBTh2AAg");
	this.shape_3.setTransform(850.9,310.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F5F5F5").s().p("EgI0ArpQhPAAg4hTQg3hUAAh2MAAAhOXQAAh2A3hUQA4hTBPAAIRpAAQBPAAA3BTQA4BUAAB2MAAABOXQAAB2g4BUQg3BThPAAg");
	this.shape_4.setTransform(655.05,310.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-249.3,334,1939.3,392);
// library properties:
lib.properties = {
	id: '4364B6A8AFEC3F4A87F6CC351FC7CE7A',
	width: 980,
	height: 630,
	fps: 24,
	color: "#669999",
	opacity: 1.00,
	manifest: [
		{src:"images/chem_atlas_1.png", id:"chem_atlas_1"},
		{src:"images/chem_atlas_2.png", id:"chem_atlas_2"},
		{src:"images/chem_atlas_3.png", id:"chem_atlas_3"},
		{src:"https://code.jquery.com/jquery-3.4.1.min.js", id:"lib/jquery-3.4.1.min.js"},
		{src:"components/sdk/anwidget.js", id:"sdk/anwidget.js"},
		{src:"components/ui/src/textinput.js", id:"an.TextInput"},
		{src:"components/ui/src/css.js", id:"an.CSS"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['4364B6A8AFEC3F4A87F6CC351FC7CE7A'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
function _updateVisibility(evt) {
	var parent = this.parent;
	var detach = this.stage == null || this._off || !parent;
	while(parent) {
		if(parent.visible) {
			parent = parent.parent;
		}
		else{
			detach = true;
			break;
		}
	}
	detach = detach && this._element && this._element._attached;
	if(detach) {
		this._element.detach();
		this.dispatchEvent('detached');
		stage.removeEventListener('drawstart', this._updateVisibilityCbk);
		this._updateVisibilityCbk = false;
	}
}
function _handleDrawEnd(evt) {
	if(this._element && this._element._attached) {
		var props = this.getConcatenatedDisplayProps(this._props), mat = props.matrix;
		var tx1 = mat.decompose(); var sx = tx1.scaleX; var sy = tx1.scaleY;
		var dp = window.devicePixelRatio || 1; var w = this.nominalBounds.width * sx; var h = this.nominalBounds.height * sy;
		mat.tx/=dp;mat.ty/=dp; mat.a/=(dp*sx);mat.b/=(dp*sx);mat.c/=(dp*sy);mat.d/=(dp*sy);
		this._element.setProperty('transform-origin', this.regX + 'px ' + this.regY + 'px');
		var x = (mat.tx + this.regX*mat.a + this.regY*mat.c - this.regX);
		var y = (mat.ty + this.regX*mat.b + this.regY*mat.d - this.regY);
		var tx = 'matrix(' + mat.a + ',' + mat.b + ',' + mat.c + ',' + mat.d + ',' + x + ',' + y + ')';
		this._element.setProperty('transform', tx);
		this._element.setProperty('width', w);
		this._element.setProperty('height', h);
		this._element.update();
	}
}

function _tick(evt) {
	var stage = this.stage;
	stage&&stage.on('drawend', this._handleDrawEnd, this, true);
	if(!this._updateVisibilityCbk) {
		this._updateVisibilityCbk = stage.on('drawstart', this._updateVisibility, this, false);
	}
}
function _componentDraw(ctx) {
	if(this._element && !this._element._attached) {
		this._element.attach($('#dom_overlay_container'));
		this.dispatchEvent('attached');
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;